"""Replay exactly the failing generator seed without expensive detector simulation."""
import os
import runpy
import FWCore.ParameterSet.Config as cms

process = runpy.run_path(os.environ['PROBE_CONFIG'])['process']
process.schedule.remove(process.simulation_step)
process.FEVTDEBUGoutput.fileName = cms.untracked.string(os.environ['PROBE_OUTPUT'])
process.MessageLogger.cerr.FwkReport.reportEvery = 100
