"""Freeze exact missing chunks and canaries; never mutate original successful outputs."""
import json
import os
from pathlib import Path
import subprocess

directory = Path(__file__).resolve().parent
workspace = directory.parents[1]
workflow = workspace / 'shift_cmssw_workflow'
audit = json.loads((directory / 'terminal_audit_20260922.json').read_text())
startup = json.loads((directory / 'submission_status.json').read_text())
jobs = []
environments = {}
for campaign in audit['campaigns']:
    root = Path(campaign['campaign'])
    original = next(c for c in startup['campaigns'] if c['cluster'] == campaign['cluster'])
    snapshot = Path(original['frozen_workflow'])
    shell = f'''set -a
source "{snapshot}/config/campaigns/{campaign['sample']}_unfiltered_2023.env"
source "{snapshot}/config/workflow.env"
python3 -c 'import json,os; print(json.dumps(dict(os.environ)))'
'''
    env = dict(os.environ, CAMPAIGN_NAME=root.name, QCD_BIN=campaign['bin'], JPSI_BIN=campaign['bin'],
               N_EVENTS='250', N_JOBS=str(campaign['expected_jobs']),
               SAMPLE_BASE='/eos/home-j/jniedzie/shift_cmssw',
               CMSSW_SRC=str(workspace/'CMSSW_17_0_0_pre4/src'))
    raw = json.loads(subprocess.run(['bash', '-c', shell], env=env, check=True,
                                   capture_output=True, text=True).stdout)
    keys = ('PROCESS','GEN_PTHAT_MIN','GEN_PTHAT_MAX','GENERATOR_SEED','SIMULATION_SEED',
            'COLLISION_YEAR','ERA','GEOMETRY','CONDITIONS','BEAMSPOT',
            'PILEUP_MODE','TRIGGER_SCENARIO','TRIGGER_TIMELINE_MODE','PIGGYBACK_FILTER_RECONSTRUCTION',
            'ENABLE_EXONANOAOD','STEP4_INPUTS_PER_JOB')
    selected = {k:v for k,v in raw.items() if k in keys or k.startswith('SHIFT_')}
    state_path = next((root/'chain_metadata').glob('part*/state.json'))
    contract = json.loads(state_path.read_text())['contract']
    for key,value in contract.items():
        if key not in ('events','chunk','fragment_sha256'):
            selected[key] = value
    assert selected['PROCESS'] == raw['PROCESS']
    environments[(campaign['sample'],campaign['bin'])] = selected
    for chunk in campaign['missing_final_ids']:
        if (root/'samples/step4'/f'events_NanoAOD_part_{chunk:04d}.root').exists():
            raise ValueError('Missing-chunk inventory changed; refresh before submission')
        jobs.append(dict(sample=campaign['sample'],bin=campaign['bin'],chunk=chunk,events=250,
                         campaign=str(root),campaign_jobs=campaign['expected_jobs'],
                         old_cluster=campaign['cluster'],environment=selected))
canaries = []
for index in range(10):
    sample,bounds = list(environments)[index % 6]
    env = dict(environments[(sample,bounds)])
    env['GENERATOR_SEED'] = str(83000000+10000*index)
    env['SIMULATION_SEED'] = str(84000000+10000*index)
    name = f'RecoveryCanary_{sample}_pThat_{bounds}_20260922_v1'
    canaries.append(dict(sample=sample,bin=bounds,chunk=index,events=2,campaign_jobs=10,
        campaign=f'/eos/home-j/jniedzie/shift_cmssw/{sample}/{name}',environment=env))
for name,rows in [('recovery_manifest.json',jobs),('canary_manifest.json',canaries)]:
    with (directory/name).open('x') as stream:
        json.dump(dict(jobs=rows,physics_changed=False,global_recovery_limit=50),stream,indent=2)
        stream.write('\n')
print('Frozen',len(jobs),'missing chunks and',len(canaries),'two-event canaries')
