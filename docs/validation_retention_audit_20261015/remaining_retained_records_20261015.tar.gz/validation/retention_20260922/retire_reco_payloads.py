"""Explicit September 22 retirement; ROOT payloads only, no broad directory removal."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import stat
import time

from clean_afs_logs import queue

REPORT = Path(__file__).resolve().parent
BASE = Path('/eos/home-j/jniedzie/shift_cmssw/jpsi')
FIXTURES = {0, 4, 500, 999}
FALLBACKS = {522, 641, 643, 645, 666, 776, 826, 928, 952}
# Only these campaign/stage combinations are eligible. All non-ROOT files stay.
TARGETS = {
    'lssPaired_control_10k_2023_v1': ('step3', 'step4', 'step4_merged'),
    'lssPaired_control_10k_2023_v2': ('step1', 'step2', 'step3', 'step4', 'step4_merged'),
    'lssPaired_materialField_10k_2023_v1': ('step4', 'step4_merged'),
    'lssPaired_materialField_10k_2023_v2': ('step1', 'step2', 'step3', 'step4', 'step4_merged'),
    'lssPaired_field_10k_2023_v3': ('step1', 'step2', 'step3', 'step4', 'step4_merged'),
    'lssPaired_material_10k_2023_v3': ('step1', 'step2', 'step3'),
}
REFERENCES = {
    'lssPaired_control_10k_2023_v3': 'ntuple_0_ca5af1024788.root',
    'lssPaired_field_10k_2023_v4': 'ntuple_0_23e835a84f21-dirty-22648d57.root',
    'lssPaired_material_10k_2023_v3': 'ntuple_0_ca5af1024788_complete.root',
    'lssPaired_materialField_10k_2023_v3': 'ntuple_0_ca5af1024788.root',
}

def record(path):
    s = path.lstat()
    if not stat.S_ISREG(s.st_mode) or path.resolve() != path:
        raise ValueError(f'Not a regular nonsymlinked file: {path}')
    return dict(path=str(path), bytes=s.st_size, mtime_ns=s.st_mtime_ns)

def healthy_root(path, expected, nano=False):
    import ROOT
    f = ROOT.TFile.Open(str(path))
    if not f or f.IsZombie() or f.TestBit(ROOT.TFile.kRecovered):
        raise ValueError(f'Unhealthy retained ROOT: {path}')
    tree = f.Get('Events')
    if not tree or tree.GetEntries() != expected:
        raise ValueError(f'Unexpected retained Events count: {path}')
    result = dict(path=str(path), events=expected)
    if nano:
        names = ('run','luminosityBlock','event','nShiftMuon','nShiftDimuonVertex')
        tree.SetBranchStatus('*', 0)
        for name in names:
            if not tree.GetBranch(name):
                raise ValueError(f'Missing branch: {name}')
            tree.SetBranchStatus(name, 1)
        totals = Counter()
        checksum = hashlib.sha256()
        for event in tree:
            values = [int(getattr(event, name)) for name in names]
            checksum.update(json.dumps(values).encode())
            totals.update(muons=values[3], vertices=values[4])
        result.update(totals=dict(totals), allowed_columns_sha256=checksum.hexdigest(),
                      enabled_branches=list(names))
    f.Close()
    result.update(record(path))
    return result

def inventory():
    delete, keep = [], []
    for campaign, stages in TARGETS.items():
        for stage in stages:
            directory = BASE / campaign / 'samples' / stage
            if not directory.is_dir() or directory.resolve() != directory:
                raise ValueError(f'Missing or symlinked target: {directory}')
            seen = set()
            for path in sorted(directory.iterdir()):
                if path.suffix != '.root':
                    continue
                r = record(path)
                match = re.search(r'_part_?(\d{4})(?:_|\.)', path.name)
                chunk = int(match[1]) if match else None
                retained = set()
                if stage in ('step1','step2','step3'):
                    retained = FALLBACKS if campaign.endswith('control_10k_2023_v1') else FIXTURES
                    if chunk is None:
                        raise ValueError(f'Unrecognized intermediate filename: {path}')
                if chunk in retained:
                    keep.append(r)
                    seen.add(chunk)
                else:
                    delete.append(r)
            if stage in ('step1','step2','step3') and seen != retained:
                raise ValueError(f'Missing retained fixture(s) in {directory}: {retained-seen}')
    return delete, keep

def validate_retained(keep):
    records = []
    for campaign, filename in REFERENCES.items():
        path = BASE / campaign / 'samples/step4_merged' / filename
        records.append(healthy_root(path, 10000, nano=True))
        print('Validated canonical reference', campaign, '10000 events', flush=True)
    for r in keep:
        records.append(healthy_root(Path(r['path']), 10))
    print('Retained intermediate fixtures checked:', len(keep), flush=True)
    return records

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--apply', action='store_true')
    args = p.parse_args()
    jobs = queue()
    if not args.apply:
        delete, keep = inventory()
        health = validate_retained(keep)
        totals = Counter()
        for r in delete:
            totals[Path(r['path']).relative_to(BASE).parts[0]] += r['bytes']
        report = dict(created=time.time(), jobs=jobs, delete=delete, keep=keep,
                      retained_health=health, totals=dict(totals),
                      bytes=sum(totals.values()), no_mass_branches_read=True,
                      authorized_by_user=True, payload_backup=False)
        with (REPORT / 'eos_preview.json').open('x') as f:
            json.dump(report, f, indent=2)
        print('Proposed ROOT deletion:', len(delete), 'files;', report['bytes'], 'bytes', flush=True)
        print(json.dumps(dict(totals), indent=2), flush=True)
        return
    report = json.loads((REPORT / 'eos_preview.json').read_text())
    delete, keep = inventory()
    if delete != report['delete'] or keep != report['keep']:
        raise ValueError('Inventory changed since review; stop')
    if validate_retained(keep) != report['retained_health']:
        raise ValueError('Retained reference/fixture changed')
    queue()
    total = 0
    count = 0
    with (REPORT / 'eos_deleted.jsonl').open('x') as receipt:
        for r in delete:
            path = Path(r['path'])
            if record(path) != r:
                raise ValueError(f'Candidate changed: {path}')
            path.unlink()
            receipt.write(json.dumps(r) + '\n')
            count += 1
            total += r['bytes']
            if count % 1000 == 0:
                receipt.flush()
                print('Removed', count, 'obsolete ROOT files', flush=True)
        receipt.flush()
    # Ensure protected files survive with the exact recorded contents/metadata.
    if validate_retained(keep) != report['retained_health']:
        raise ValueError('Post-cleanup retained health differs')
    remaining = [r['path'] for r in delete if Path(r['path']).exists()]
    if remaining:
        raise ValueError('Some deleted files still exist')
    with (REPORT / 'eos_result.json').open('x') as f:
        json.dump(dict(finished=time.time(), files=count, bytes=total,
            totals=report['totals'], retained_verified=True,
            obsolete_payloads_not_backed_up=True), f, indent=2)
    print('Finished retirement:', count, 'files;', total, 'bytes; all retained references verified.', flush=True)

if __name__ == '__main__':
    main()
