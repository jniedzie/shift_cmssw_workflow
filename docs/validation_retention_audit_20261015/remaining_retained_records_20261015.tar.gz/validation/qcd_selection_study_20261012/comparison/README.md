# QCD selection study, 2026-10-12

The useful improvement is to let the existing natural muon-producing decays
finish **before** deciding which events get expensive detector simulation.
Guessing from the undecayed parent particles did not give a useful gain.
This is a modest improvement, not a solution that creates thousands of tail
events from the current small pool.

## Completed checks

- Original-GEN comparison: all 60,080 admitted QCD events, with the existing
  36,118 train / 12,047 validation / 11,915 test source-event split.
  Rules and probabilities were saved and hashed before looking at held-out
  outcomes. No reconstructed quantity entered a rule.
- Follow-up: full `GenPart` daughter information for every event, including
  events with no reconstructed muons. All 169 merged input files passed
  byte-count and Adler32 checks. Every event identity and weight matched the
  existing pool. The frozen V10 runtime and both GEN-only pruners preserve all
  stable muons. The recorded momentum and vertices use full float precision.
- Twelve tests passed for probabilities, weights, event splits, empty events,
  source identities, forbidden reconstructed fields and missing tail support.
- All same-event candidate identities reproduced the recorded selection.
  Before choosing the best pair there are 118 accepted Both-Both combinations,
  versus 113 stored. The extra five are all below 10 GeV. The largest Both-Both
  mass is 9.243 GeV. Candidate arbitration is not hiding a high-mass sample.

## Results

These are expected retained **distinct source events** when keeping about 20%
of the observed pool, with at least a 10% random remainder in every group.
They are comparisons with a random sample of the same expected size. They
are not newly produced events or measured CPU savings.

| Fixed rule after natural decays | Both-Both event gain | pT > 20 GeV event gain | Weighted Both-Both second moment / random |
|---|---:|---:|---:|
| Two forward GEN muons, p > 10 GeV | 1.68 | 1.87 | 0.378 |
| Two muon lines crossing >=1 CSC station in each endcap | 1.59 | 1.66 | 1.350 |
| Two muon lines crossing >=2 CSC stations in each endcap | 1.65 | 1.78 | 1.343 |

Forward means the unchanged historical condition `-10 < eta < 0`.
Six rules were fixed before this follow-up: one/two forward muons above 10 GeV,
and one/two actual chamber-crossing muon lines with one/two stations per side.
There was no new threshold search.

The broad two-forward rule keeps important low-bin events that the straight-line
chamber test misses. The straight-line estimate omits bending, material and
secondary production. Its similar raw count hides worse weighted errors.
The broad rule's 0.378 second-moment ratio is promising for a small new test;
it does not establish a 2.65-fold improvement in the final physics result.

The original-GEN parent rule chosen on train gave only 1.06 times the held-out
Both-Both count, with a 95% interval of 0.965–1.147, and no high-pT gain.
It does not support a large parent-selected campaign.

## Weights and limits

The native GEN weight is `W`. The existing detector-sampling probability is
`p`. Its physical weight is `sigma/full_GEN_sumw * W/p`. For an extra independent
selection with probability `q`, divide that existing weight by `q` once.
The study's weighted second moment is conditional on this extra sampling of
the observed pool; the original full-GEN denominator stays unchanged.
Actual deployment probabilities must be calibrated on the new GEN population.
Old and overlapping new draws cannot simply be added with their old weights.

The follow-up is **exploratory**: the existing held-out outcomes had already
been examined in the preceding study. A fresh detector pilot with independent
source events is needed. It must preserve the completed decay particles,
vertices and times exactly; filtering and then rerunning the decay RNG would
otherwise change the event. No Both-Both event above 10 GeV exists here, so
neither a high-mass QCD rate nor a mass-tail gain has been validated.

Primary evidence: `comparison.json`, `chosen_rules.json`,
`after_decay/comparison.json`, `after_decay/extraction_receipt.json`,
`after_decay/provenance.json`, `real_same_event_pair_support.json`,
`tests_receipt.json` and `decision_evidence.json`. Diagnostic source snapshots
and hashes are preserved in `reproducer/`.

## Fresh V11 pilot check

All 60 pilot jobs completed and their 1,200 Nano events passed exact identity,
native-weight, sampling-probability and corrected-weight checks against the
frozen event ledger. There are 1,085 source events absent from the old pool and
115 overlaps; the two groups remain separate.

The new-source group has 155 reconstructed muons, nine stored OS pairs and
two Both-Both pairs. Both new Both-Both events pass the already-frozen broad
two-forward-daughter rule. One has no GEN muon ray crossing both CSC endcaps,
so a hard straight-line chamber test would discard a useful event. The fixed
random remainder protects against this loss.

There is no muon above 20 GeV pT and no pair mass above 10 GeV in the pilot.
The largest muon pT is 15.34 GeV; the largest pair mass is 5.95 GeV, and the
largest Both-Both mass is 3.95 GeV. Two new Both-Both events are too few to
validate an efficiency gain or normalization. No rule or probability was
retuned using this check. No cross-section rate is assigned to the pilot.

Exact counts, frozen-rule results, job receipt hashes and overlap accounting
are in `v11_fresh_pilot/receipt.json`; its compact per-event evidence is
`v11_fresh_pilot/events.jsonl.gz`.
