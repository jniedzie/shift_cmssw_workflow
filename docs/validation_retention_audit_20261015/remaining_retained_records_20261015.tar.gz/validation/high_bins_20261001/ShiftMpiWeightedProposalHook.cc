// Isolated registered hook. Requires the exact frozen 8.317 path-weight overlay.
#include "FWCore/ParameterSet/interface/ParameterSet.h"
#include "FWCore/Utilities/interface/Exception.h"
#include "GeneratorInterface/Pythia8Interface/interface/CustomHook.h"
#include "Pythia8/Pythia.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <string>
#include <array>
extern "C" double shift_mpi_weight(),shift_mpi_event_weight(),shift_mpi_sigma_nd(),shift_mpi_sumw(),shift_mpi_sumw2(),shift_mpi_norm_max(),shift_mpi_path_min(),shift_mpi_path_max();
extern "C" long shift_mpi_calls(),shift_mpi_event_calls(),shift_mpi_framework_slots(),shift_mpi_ordinary_calls(),shift_mpi_accepted(),shift_mpi_norm_trials(),shift_mpi_zero_trials(),shift_mpi_kin_failures(),shift_mpi_path_factors();
extern "C" bool shift_mpi_failure();
extern "C" void shift_mpi_reset_stats(),shift_mpi_begin_event();
namespace {
bool isDirect(int id) {id=std::abs(id);return id==443 || id==9940003 || id==9941003 || id==9942003;}
double directScale(const Pythia8::Event& event) {
  double value=-1.;for(int i=0;i<event.size();++i)if((std::abs(event[i].status())==23 || std::abs(event[i].status())==33)&&isDirect(event[i].id()))value=std::max(value,event[i].pT());return value;
}
}
class ShiftMpiWeightedProposalHook final : public Pythia8::UserHooks {
public:
  explicit ShiftMpiWeightedProposalHook(const edm::ParameterSet& p):
    sample(p.getParameter<std::string>("eventClass")),lower(p.getParameter<double>("pTHatMin")),upper(p.getParameter<double>("pTHatMax")),
    budget(p.getParameter<unsigned int>("proposalTrials")),run(p.getParameter<unsigned int>("eventRun")),statsFile(p.getParameter<std::string>("statisticsFile")) {
    if((sample!="qcd" && sample!="direct_jpsi") || !std::isfinite(lower) || lower<=0 || !std::isfinite(upper) || (upper!=-1. && upper<=lower) || !budget || run<30000000)throw cms::Exception("Configuration")<<"Invalid weighted proposal partition/trial namespace";
    setenv("SHIFT_MPI_TAIL_LOWER",std::to_string(lower).c_str(),1);
    if(sample=="direct_jpsi")setenv("SHIFT_MPI_BIAS_FIRST_JPSI","1",1);else unsetenv("SHIFT_MPI_BIAS_FIRST_JPSI");
  }
  bool initAfterBeams() override {
    if(++initializations!=1)throw cms::Exception("Configuration")<<"Fixed-budget weighted GEN requires one Pythia initialization, one run and one lumi";
    if(!flag("SoftQCD:nonDiffractive") || flag("HardQCD:all") || flag("Charmonium:all") || mode("MultipartonInteractions:processLevel")!=3 || mode("MultipartonInteractions:bProfile")!=2 || flag("MultipartonInteractions:allowRescatter") || mode("MultipartonInteractions:pTmaxMatch")!=0 || flag("Beams:allowMomentumSpread") || !flag("Check:abortIfVeto") || flag("Stat:reset"))throw cms::Exception("Configuration")<<"Weighted proposal source or retry contract changed";
    shift_mpi_reset_stats();return true;
  }
  bool canVetoMPIStep() override{return true;}
  int numberVetoMPIStep() override{return 1;}
  bool retryPartonLevel() override{return false;}
  bool canVetoPT() override{return false;}
  double scaleVetoPT() override{return lower;}
  bool canVetoPartonLevel() override{return true;}
  bool doVetoMPIStep(int n,const Pythia8::Event& event) override {
    if(n!=1)return false;
    firstLimit=std::max(infoPtr->pTHat(),std::sqrt(std::max(0.,infoPtr->Q2Fac())));
    // Only zero-likelihood proposals may abort before intrinsic retry decisions.
    const bool reject=shift_mpi_event_weight()==0.;
    if(reject)deliberateVeto=true;return reject;
  }
  bool doVetoPT(int,const Pythia8::Event& event) override {
    const double scale=directScale(event);bool reject=scale<lower || (upper>=0 && scale>=upper);if(reject)deliberateVeto=true;return reject;
  }
  bool doVetoPartonLevel(const Pythia8::Event& event) override {
    const double jpsi=directScale(event),scale=sample=="qcd"?infoPtr->pTHat():jpsi;
    if(jpsi>firstLimit+1e-8)throw cms::Exception("LogicError")<<"Direct state exceeds proved first-MPI upper bound";
    const bool owns=sample=="qcd"?jpsi<0:jpsi>=0;
    const bool reject=!(owns && scale>=lower && (upper<0 || scale<upper));
    if(reject){deliberateVeto=true;return true;}
    const double w=shift_mpi_event_weight();
    if(!std::isfinite(w) || w<=0)throw cms::Exception("LogicError")<<"Nonpositive/nonfinite proposal likelihood";
    infoPtr->weightContainerPtr->setWeightNominal(w);return false;
  }
protected:
  void onBeginEvent() override {++nextCalls;shift_mpi_begin_event();deliberateVeto=false;if(nextCalls>budget)throw cms::Exception("LogicError")<<"Framework exceeded fixed proposal budget";}
  void onEndEvent(Status status) override {
    if(status==COMPLETE)++successful;
    else if(!deliberateVeto || (status!=PARTONLEVEL_FAILED && status!=PARTONLEVEL_USERVETO))++unexpected;
    if(status>=0 && status<16)++statuses[status];
    if(shift_mpi_framework_slots()!=nextCalls || shift_mpi_event_calls()<1 || shift_mpi_calls()!=accountedProposalCalls+shift_mpi_event_calls() || infoPtr->nTried()!=nextCalls || shift_mpi_accepted()!=successful)++accountingFailures;
    accountedProposalCalls=shift_mpi_calls();maxProposalCallsPerSlot=std::max(maxProposalCallsPerSlot,shift_mpi_event_calls());
    if(shift_mpi_event_calls()>1)++intrinsicRetrySlots;
    if(nextCalls%10000==0 || nextCalls==budget || unexpected || accountingFailures)writeStats();
    if(unexpected || accountingFailures)throw cms::Exception("LogicError")<<"Fixed-trial proposal accounting failed: calls="<<shift_mpi_calls()<<" tried="<<infoPtr->nTried()<<" slots="<<nextCalls<<" successful="<<successful<<" accumulated="<<shift_mpi_accepted();
  }
  void onStat() override {writeStats();}
private:
  void writeStats() const {
    const std::string temporary=statsFile+".tmp";std::ofstream out(temporary);out<<std::setprecision(17)
      <<"{\"schema\":\"shift-weighted-fixed-trial-ledger-v3\",\"algorithm\":\"independent-geometric-full-support-tail-channel-retry-rb-v4\",\"sample\":\""<<sample<<"\",\"lower\":"<<lower<<",\"upper\":"<<upper<<",\"requested_trials\":"<<budget<<",\"framework_slots\":"<<nextCalls<<",\"tried\":"<<infoPtr->nTried()<<",\"proposal_calls\":"<<shift_mpi_calls()<<",\"accounted_proposal_calls\":"<<accountedProposalCalls<<",\"max_proposal_calls_per_slot\":"<<maxProposalCallsPerSlot<<",\"intrinsic_retry_slots\":"<<intrinsicRetrySlots<<",\"ordinary_proposal_calls\":"<<shift_mpi_ordinary_calls()<<",\"ordinary_proposal_fraction\":0.1,\"accepted\":"<<successful<<",\"accumulated_accepted\":"<<shift_mpi_accepted()<<",\"sumw\":"<<shift_mpi_sumw()<<",\"sumw2\":"<<shift_mpi_sumw2()<<",\"sigma_nd_mb\":"<<shift_mpi_sigma_nd()<<",\"sigma_mb\":"<<(nextCalls?shift_mpi_sigma_nd()*shift_mpi_sumw()/nextCalls:0.)<<",\"sigma_error_mb\":"<<(nextCalls>1?shift_mpi_sigma_nd()*std::sqrt(std::max(0.,shift_mpi_sumw2()-shift_mpi_sumw()*shift_mpi_sumw()/nextCalls)/(double(nextCalls)*(nextCalls-1))):0.)<<",\"native_cached_sigma_mb\":"<<infoPtr->sigmaGen()<<",\"run\":"<<run<<",\"lumi\":1,\"first_parent_event\":1,\"last_parent_event\":"<<nextCalls<<",\"initializations\":"<<initializations<<",\"unexpected_failures\":"<<unexpected<<",\"accounting_failures\":"<<accountingFailures<<",\"normalizer_trials\":"<<shift_mpi_norm_trials()<<",\"normalizer_max\":"<<shift_mpi_norm_max()<<",\"zero_proposals\":"<<shift_mpi_zero_trials()<<",\"handled_kinematic_failures\":"<<shift_mpi_kin_failures()<<",\"path_factors\":"<<shift_mpi_path_factors()<<",\"path_min\":"<<shift_mpi_path_min()<<",\"path_max\":"<<shift_mpi_path_max()<<",\"complete\":"<<(nextCalls==budget && !unexpected && !accountingFailures?"true":"false")<<",\"native_gen_lumi_is_trial_ledger\":false,\"physics_valid\":false,\"normalization_ready\":false,\"status_counts\":[";
    for(unsigned i=0;i<statuses.size();++i){if(i)out<<',';out<<statuses[i];}out<<"]}\n";out.close();if(std::rename(temporary.c_str(),statsFile.c_str()))throw cms::Exception("FileWriteError")<<"Cannot publish fixed-trial ledger";
  }
  std::string sample;double lower,upper,firstLimit=0.;unsigned budget,run;std::string statsFile;
  unsigned initializations=0;long nextCalls=0,successful=0,unexpected=0,accountingFailures=0,accountedProposalCalls=0,maxProposalCallsPerSlot=0,intrinsicRetrySlots=0;bool deliberateVeto=false;std::array<long,16> statuses{};
};
REGISTER_USERHOOK(ShiftMpiWeightedProposalHook);
