# September 23 morning handoff

## User decision

Leave the remaining jobs running overnight. Do not implement the earlier
cancellation/partial-merge suggestion. First tomorrow: validate and merge this
ATLAS-proxy production to study useful statistics and analysis machinery.
Then prepare separate production with the updated CMS LSS geometry after its
validation gates pass. No jobs changed, no merge/submission started, and no
continuous monitor installed during this notes-only handoff.

## Snapshot: September 22, 16:53 CERN

Recovery cluster **1960281 on bigbird21.cern.ch**: **57 running, zero idle or
held**, 269 successful recovery exits, no recorded failed exits or evictions.
All 326 recovery jobs have materialized; live cap 326, idle throttle 50.
Including the 994 original successes: 1263/1320 successful chunks. Refresh
tomorrow; this does not establish final ROOT integrity or overnight success.

| Sample | pThat 1--2 | pThat 2--5 | pThat 5--10 |
| --- | ---: | ---: | ---: |
| QCD | 400/400 | 400/400 | 352/400 |
| J/psi | 40/40 | 40/40 | 31/40 |

## Locations

Base: `/eos/home-j/jniedzie/shift_cmssw/`.

- `qcd/QCD_UnfilteredDecays_pThat_<bin>_ATLASproxy_100k_20260921_v1`
- `jpsi/Jpsi_Unfiltered_pThat_<bin>_ATLASproxy_10k_20260921_v1`
- `<bin>` is `1to2`, `2to5`, or `5to10`.
- Inputs: `<campaign>/samples/step4/events_NanoAOD_part_NNNN.root`.
- Outputs: `<campaign>/samples/step4_merged/`, one validated ROOT per bin.
- Exact recovery rows: `recovery_manifest.json`; Condor ProcId-to-chunk map:
  `recovery_queue_map.json`. ProcId is NOT the production chunk index.
- Original successful sets: `terminal_audit_20260922.json`. The old AFS logs
  were intentionally deleted; do not rerun `audit_terminal_logs.py`, which
  needs them. Keep its saved audit and use current recovery logs/checkpoints.

## Morning procedure

1. Run `condor_q -name bigbird21.cern.ch 1960281 -factory` and a normal job
   query. Query failure is unknown state, not completion. Reconcile recovery
   event logs/history, original successes and EOS checkpoints. Inspect failures
   before targeted recovery; never resubmit the whole campaign or clear locks
   blindly. Do not rebuild shared CMSSW while jobs use it.
2. Require exactly chunks 0000--0399 for QCD or 0000--0039 for J/psi,
   successful exits, four-stage checkpoints and no active locks. Merge complete
   bins independently; if one remains incomplete, report it, not a partial
   sample as complete. Preserve all configs, logs, seeds and bookkeeping.
3. Reopen every Nano: healthy/unrecovered ROOT, common schema, full event-ID
   equality with GEN metadata, disjoint IDs, unit genWeight, matching counts,
   hashes and checkpoint provenance. Read only IDs, weights, muon/vertex counts
   and topology labels. Never read, print or plot reconstructed mass branches.
4. From the workflow checkout, with SAMPLE_DIR the exact campaign and N_JOBS
   400 or 40, combine complete normalization:

   ```bash
   python3 scripts/collect_generation_metadata.py "$SAMPLE_DIR/generation_metadata" \
     --expected-chunks "$N_JOBS" --output "$SAMPLE_DIR/normalization_complete.json" \
     --cross-section-output "$SAMPLE_DIR/cross_sections_complete.txt"
   ```

   Do not overwrite existing valid exports or use first-worker cross sections.
   Use actual metadata event totals, not 250 times chunk count. Known GEN
   cases with 249 valid events from 250 slots: QCD 2--5 chunks 4 and 184,
   QCD 5--10 chunk 241. Recompute from all metadata, not these examples alone.
5. Merge in local scratch, not AFS; check scratch capacity first. Previous
   validated merges used compression-preserving `hadd -fk -j 2`. Never skip
   corrupt/missing files. Check the full source union against the aggregate,
   publish with a unique partial name/checksum, then independently reopen EOS
   output. Suggested name: `ntuple_complete_<actual_events>events_20260923.root`.
6. Hand off exact paths, tags, event counts, combined cross sections and audits.
   Preserve the user's analysis-config edits; ensure the new normalization is
   explicitly selected rather than silently using old hard-coded values.

## Small merge-tool task still needed

There is no validated general merge driver yet for this new unfiltered chain.
Reuse `run_retiring_chain.py` checks and `collect_generation_metadata.py`.
`merge_complete_qcd.py` is a starting point only: its filename is hard-coded
to September 21, it checks metadata ID endpoints rather than the complete list,
lacks current checkpoint/weight checks, assumes the destination directory
exists, and needs a published-file reopen. Generalize minimally/test or compose
a bounded driver tomorrow. `merge_sampling_nano.inspect` checks IDs/topology/
schema but not genWeight. Do not apply old sampling/replay drivers or sidecars.

These are unit-weight, unfiltered samples: no 10% sampling correction or extra
muon-filter efficiency. Use combined cross section and actual total events.
Forced-J/psi branching convention remains provisional; do not double-apply a
branching fraction. Keep ATLAS-proxy, no-pileup/no-trigger and low-pThat coverage
limitations visible. These are not effective-luminosity or CMS physics results.

## Following CMS-geometry production

Use new tags and a pinned geometry checksum; never mix geometries or mutate
live configs. Require CMS/IR5 completeness, overlap/gap, material, transform
and transport validation. Preserve CMS 2023 generator settings, process
ownership, unfiltered generation and fixed electronics/trigger behavior.
Regenerate geometry-dependent GEN-SIM and downstream stages, not Step 4 alone
on proxy SimHits. A pure generator configuration can be reused; old transport
cannot establish the new geometry.

First run a bounded end-to-end pilot with resolved-config, timing, integrity,
normalization and CPU/memory/disk checks. Freeze a scratch-staged runtime before
scaling; retain safe intermediate retirement and inactive AFS-log cleanup.
Use this sample's statistics to choose new sizes. The 0--1 GeV model remains
unresolved; do not silently add it or launch before the geometry/pilot gates.

Last measured headroom: about 4.75 GiB AFS and over 610 GB EOS logical; recheck
before merging. Cleanup code/docs changes are uncommitted; preserve them and
unrelated TEA edits. Old deleted logs/payloads are not backed up; conclusions,
canonical references and small regression inputs remain. No commit requested.
