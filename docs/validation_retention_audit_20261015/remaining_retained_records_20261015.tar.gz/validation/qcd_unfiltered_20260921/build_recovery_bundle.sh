#!/usr/bin/env bash
set -euo pipefail
workspace=/afs/cern.ch/work/j/jniedzie/private/shift_cmssw
destination=/eos/home-j/jniedzie/shift_cmssw/production_recovery/20260922_v1
staging=$(mktemp -d /tmp/shift_recovery_bundle_XXXXXX)
mkdir "$staging/CMSSW_17_0_0_pre4" "$staging/workflow"
tar -xzf /tmp/shift_runtime_20260922_HZHvCr/cmssw_runtime.tar.gz -C "$staging/CMSSW_17_0_0_pre4"
rsync -a --exclude=.git --exclude=/condor --exclude=__pycache__ \
  "$workspace/shift_cmssw_workflow/" "$staging/workflow/"
cp "$workspace/validation/qcd_unfiltered_20260921/"{recovery,canary}_manifest.json "$staging/"
archive=$staging/payload.tar.gz
tar --format=pax -C "$staging" -czf "$archive" CMSSW_17_0_0_pre4 workflow recovery_manifest.json canary_manifest.json
mkdir -p "$destination"
[[ ! -e "$destination/payload.tar.gz" ]] || exit 2
cp "$archive" "$destination/payload.tar.gz"
sha256sum "$archive" "$destination/payload.tar.gz"
printf 'Bundle staging directory: %s\n' "$staging"
