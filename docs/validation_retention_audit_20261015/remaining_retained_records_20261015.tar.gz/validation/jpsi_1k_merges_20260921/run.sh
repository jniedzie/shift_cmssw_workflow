#!/usr/bin/env bash
set -eo pipefail
workspace=/afs/cern.ch/work/j/jniedzie/private/shift_cmssw
validation="$workspace/validation/jpsi_1k_merges_20260921"
source /cvmfs/cms.cern.ch/cmsset_default.sh
cd "$workspace/CMSSW_17_0_0_pre4/src"
eval "$(scram runtime -sh)"
export TMPDIR=/tmp/jniedzie
python3 "$workspace/shift_cmssw_workflow/scripts/summarize_sampling_scan.py" \
  "$workspace/validation/sampling_scan_20260921_v10/jpsi.jobs" \
  --output "$validation/summary.json"
python3 "$workspace/shift_cmssw_workflow/scripts/merge_sampling_nano.py" \
  "$validation/summary.json" --sample jpsi --campaign-tag analysis1k_chunk50 \
  --output "$validation/merges.json"
