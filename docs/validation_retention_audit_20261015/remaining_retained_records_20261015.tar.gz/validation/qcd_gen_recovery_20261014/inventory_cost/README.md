<!-- Code style: human-code. -->

Read-only inventory and reconstruction cost check, 14 October 2026.

The frozen parent sample contains 3,335,630 saved accepted GEN events in
3,355 files. Its original detector draw contained 190,174 events. Fresh
completion receipts and Nano file sizes confirm 187,214 returned events in
9,911 jobs; 149 jobs containing 2,960 selected events are still missing.
QCD has 2,866,485 parent events and 60,080 returned events. Four QCD jobs
containing 78 events remain missing.

The original draw used only native GEN weights. Five low QCD bins had
uniform probability 0.1. Weighted high bins used probability proportional
to the absolute native weight. It did not select on pointing, muon count,
generated mass, transverse momentum or later reconstructed outcomes.

The QCD 20+ parent has 2,366,485 saved accepted events from 4,180,000 fixed
trials. Accepted GEN rows are not attempted source trials. The original
cross sections, trial ledgers and normalization remain authoritative.

Evidence:

- `parent_gen_census.json` and `parent_gen_sources.jsonl`: every original GEN
  file still resolves; all 655 weighted parent ledger hashes match their
  original records and preserve complete attempted/accepted accounting.
- `inventory_runtime.json` and `receipt_rows.jsonl`: fresh per-job receipt
  hashes, event identities, five tier counts and Nano byte sizes. This
  check does not rerun all ROOT semantic audits or Nano payload hashes.
- `missing_job_intervals.json` and `missing_failed_attempt_rows.jsonl`: the
  149 missing baseline jobs, with all 447 preserved failed attempts.
- `missing_qcd_jobs.json` and `failures/`: exact four QCD job descriptors,
  selected indices, original probabilities and repeated NANO stall records.
  Failed evidence archives contain configs and logs, but no RECO ROOT files.
- `reconstruct_all_cost_scenario.json`: measured successful application
  times, remaining event counts and storage scenarios. It is a workload
  calculation, not a scheduler completion date.
- `returned_identity_and_receipt_immutability.json`: all 9,911 fresh receipt
  hashes agree with the frozen inventory; all 187,214 event identities are
  unique within their process-bin domain.
- `native_history_12901384_latest20.json`: bounded native scheduler read of
  the latest twenty completed V11 pilot workers. All exit codes are zero.
  This is a duration-biased subset and is not used for the cost projection.

At the old successful-event speeds and twenty-event chunking, completing
all remaining SM parent events would use about 239,337 worker-hours and
262 GB of additional Nano files. That is about twenty days if 500 workers
were continuously running. Completing the five lower QCD bins alone would
use about 19,208 worker-hours and 35 GB, or 1.6 days at 500 continuously
running workers. The weighted high-bin draw does not establish the runtime
of its unsampled complement. Queue wait, runtime unpacking, failures,
later histograms/merges and metadata storage add work. The 447 retained
failed attempts already account for at least 380.6 application hours.

Practical next step: recover the deterministic missing QCD events separately
and measure a fixed independent sample of previously unprocessed GEN events
before allocating the full reconstruction campaign. Prefer complete lower
QCD coverage if the measured cost remains affordable. Keep the actual old
completion set separate from the new complement, and update its weights
through the validated partition convention before combining outputs.

No campaign was changed, submitted, cancelled or deleted by this audit.
The canonical analysis and reconstruction notes remain the project records.
