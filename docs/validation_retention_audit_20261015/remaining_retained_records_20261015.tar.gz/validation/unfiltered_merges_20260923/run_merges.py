import json
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

workspace = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(workspace/'shift_cmssw_workflow/scripts'))
from merge_unfiltered_production import merge

directory = Path(__file__).resolve().parent
prior = workspace/'validation/qcd_unfiltered_20260921'
query = subprocess.run(['condor_q','-name','bigbird21.cern.ch','1960281','-json'],
    capture_output=True,text=True,timeout=30,check=True)
if query.stderr.strip():
    raise RuntimeError(query.stderr)
if query.stdout.strip():
    jobs = json.loads(query.stdout)
else:
    totals = subprocess.run(['condor_q','-name','bigbird21.cern.ch','1960281','-totals'],
        capture_output=True,text=True,timeout=30,check=True)
    if totals.stderr.strip() or 'Total for query: 0 jobs;' not in totals.stdout:
        raise RuntimeError('Empty JSON response not corroborated by explicit queue totals')
    jobs = []
if jobs:
    raise RuntimeError('Recovery jobs remain; refresh audit before merging')
log = (prior/'recovery_condor_logs/1960281.log').read_text()
exits = re.findall(r'005 \(1960281\.(\d+)\.000\).*?\n(.*?)(?=\n\.\.\.)',log,re.S)
if (len(exits)!=326 or {int(i) for i,_ in exits} != set(range(326)) or
        any('Normal termination (return value 0)' not in text for _,text in exits)):
    raise RuntimeError('Recovery terminal logs are not all successful')
campaigns = json.loads((prior/'terminal_audit_20260922.json').read_text())['campaigns']
audit = dict(checked_at=datetime.now(timezone.utc).isoformat(), recovery_successes=326,
             scheduler_jobs=jobs,original_successes=sum(r['successful_jobs'] for r in campaigns),
             original_audit=str(prior/'terminal_audit_20260922.json'))
with (directory/'scheduler_audit.json').open('x') as f:
    json.dump(audit,f,indent=2)
reports=[]
for row in sorted(campaigns,key=lambda r:(r['sample'],r['bin'])):
    reports.append(merge(Path(row['campaign']),row['expected_jobs'],directory,'20260923'))
    with (directory/'ready_samples.json').open('w') as f:
        json.dump([dict(tag=Path(r['campaign']).name,output=r['output'],events=r['events'],
                       cross_section_pb=r['normalization']['cross_section_pb'],
                       normalization=str(Path(r['campaign'])/'normalization_complete.json'))
                   for r in reports],f,indent=2)
print('ALL SIX COMPLETE BINS VALIDATED AND MERGED',flush=True)
