"""Prioritize reusable late-stage checkpoints, retaining exact manifest row IDs."""
import json
from pathlib import Path

directory=Path(__file__).resolve().parent
manifest=json.loads((directory/'recovery_manifest.json').read_text())
keys=('PROCESS','GEN_PTHAT_MIN','GEN_PTHAT_MAX','GENERATOR_SEED','SIMULATION_SEED',
      'COLLISION_YEAR','ERA','GEOMETRY','CONDITIONS','BEAMSPOT','CMSSW_RUNTIME_FINGERPRINT')
order=[]
for index,row in enumerate(manifest['jobs']):
    state_path=Path(row['campaign'])/'chain_metadata'/f'part{row["chunk"]:04d}'/'state.json'
    highest=0
    if state_path.exists():
        state=json.loads(state_path.read_text())
        highest=max(map(int,state['stages']),default=0)
        expected={k:v for k,v in state['contract'].items() if k in keys or k.startswith('SHIFT_')}
        actual={k:v for k,v in row['environment'].items() if k in keys or k.startswith('SHIFT_')}
        if actual != expected:
            raise ValueError(('Checkpoint contract differs',index,
                             {k:(expected.get(k),actual.get(k)) for k in expected.keys()|actual.keys()
                              if expected.get(k)!=actual.get(k)}))
    order.append((index,highest,row['sample'],row['bin'],row['chunk']))
order.sort(key=lambda r:(-r[1],r[2]!='jpsi',r[4],r[3]))
submit=(directory/'recovery.sub').read_text()
submit=submit.replace('recovery_manifest.json $(Process)', 'recovery_manifest.json $(ROW)')
submit=submit.replace('queue 326\n', '+RecoveryManifestRow = $(ROW)\nqueue ROW from (\n'+
                      '\n'.join(str(row[0]) for row in order)+'\n)\n')
with (directory/'recovery_ordered.sub').open('x') as stream:stream.write(submit)
with (directory/'recovery_queue_map.json').open('x') as stream:
    json.dump([dict(proc=i,manifest_row=r[0],checkpoint_stage=r[1],sample=r[2],bin=r[3],chunk=r[4])
               for i,r in enumerate(order)],stream,indent=2)
print('Verified',len(order),'contracts; first 10 checkpoints:',[(r[1],r[2],r[3],r[4]) for r in order[:10]])
