# QCD tail study, 2026-10-12

The useful change is to finish the ordinary natural decays before choosing
events for expensive detector simulation. Selecting from undecayed parent
directions did not help enough. Looking at the actual daughter muons gives
an exploratory 1.68-fold increase in Both-Both counts for the same expected
number of detector events. The high-mass deficit remains unresolved.

This is the durable handoff for the user-authorized hour beginning
2026-10-12 09:52:31 UTC. `handoff.json` records the final checked job state.

## Evidence

- [Selection and weights](comparison/README.md): original-GEN rules frozen
  before held-out comparison; six fixed post-decay rules; limits on the
  exploratory follow-up and the fresh V11 check.
- [Original-source extraction](features/README.md): all 60,080 events matched
  to 709 GEN files, six byte-hash checks, immutable 1,000-event scout graphs,
  identity/weight/conservation audits, and scout metadata limitations.
- [Detector handoff checks](geometry/README.md): actual CSC geometry,
  unchanged completed graph/time/weights, resolved full SIM and Nano configs,
  corrected missing-filter-Lumi handling, and independent replay review.
- [Reconstruction census](diagnostics/reconstructed_tail_census.json):
  113 stored Both-Both pairs, effective count 14.53, and the extreme-track list.
- [Real same-event support](comparison/real_same_event_pair_support.json):
  all 118 admissible Both-Both combinations below 10 GeV; maximum 9.243 GeV.
- [Fresh random pilot](comparison/v11_fresh_pilot/receipt.json): all 60 jobs
  and 1,200 identities/weights checked; 1,085 new source identities and 115
  old overlaps. The new events give two Both-Both pairs, no muon pT above
  20 GeV and no dimuon mass above 10 GeV. Both new Both-Both events pass the
  frozen broad daughter rule; one would fail strict straight-line geometry.
- [Original-GEN comparison figure](comparison/original_gen_selection_comparison.pdf):
  raw gains and conditional weighted error comparison, with validation limits.

## Jobs and their purpose

| Cluster | Events | Purpose | Deployment |
|---|---:|---|---|
| 12902043, procs 0/1 | 20 each | Replay known extreme tracks with original V10 seeds; retain SIM/AOD/Nano | `outlier_replay/` |
| 12902304, proc 0 | 2 | Pass a saved completed decay graph through SIM/DIGIHLT/RECO/NANO | `decay_canary_v2/` |
| 12902266, proc 0 | 2 | Superseded first handoff test, missing optional filter-counter flag | `decay_canary/` |

The first canary's submitted inputs remain immutable. The corrected canary
uses the existing `missing_filter_lumi=True` option; independent resolved
checks show only the optional genFilter table is removed. All 1,487 module
settings remain unchanged. Published inputs were read back byte-identically.
None of these repeated source events count as new independent statistics.

**Final canary result:** 12902304 passed SIM/DIGIHLT/RECO but failed Nano.
The archived worker entry point did not honor this descriptor override and
still scheduled genFilterTable, which then requested the missing original
GEN Lumi counter. The current local builder's resolved check did not test
that archived entry point. See `features/decay_scout/failure_v2/` for the
exact logs/configurations. Preserve original GEN Lumi metadata in the scout
output or validate a corrected worker in an independent frozen runtime,
then repeat the full-chain test. The failed job is held, and no selection
campaign is ready to scale.

The previous V11 random pilot 12901384 is complete. Supervisors 12901344 and
12901346 remain held. No large random bulk factory has been released.

## Resume

1. Read `handoff.json`, query queue and history for the exact clusters above,
   then inspect the local deployment `results/` files. Do not resubmit from
   an empty queue alone. Each deployment has a submission intent and receipt.
2. Check full worker completion, all tier event identities/native weights,
   published ROOT content and read-back hashes. For the outlier tests also
   require `retention_complete.json` and verified SIM/AOD hashes.
3. Compare the replayed extreme tracks with the original Nano and trace the
   original/refitted track states and matched SimHits at the same position.
   Large reconstructed/source momentum differences do not identify the fit
   mechanism by themselves. Keep the signal response in any proposed fix.
4. If the corrected handoff completes, prepare a new representative GEN draw
   with a full exposure ledger. Complete natural decays once, save the graph,
   calibrate selection probabilities on those GEN-only features, freeze the
   broad two-forward-daughter rule and a positive random remainder, then
   reconstruct the saved events. Reuse the graph, not a new decay RNG draw.
5. Use a fresh source-event pilot to measure raw Both-Both and pT/mass tail
   counts, weighted errors and actual runtime. Keep old/new overlaps explicit.
   Scale only if those results justify the added detector cost. There is no
   validated high-mass QCD gain yet.

The 1,000 scout events are fixed prefixes of six source files. They are useful
for execution tests but cannot define a full-bin physical rate. The old
conditional probabilities were calibrated on the observed detector pool;
they must not be copied blindly onto a new full-GEN population.

For native weight W, first-stage probability p and post-decay probability q,
the retained event carries W/(p*q), once, with the original full-GEN
normalization. Persist accepted and rejected identities, weights, both
probabilities, full denominators, graph hashes and seeds. Repeated decay
draws or overlapping campaigns share original source-event uncertainty.
Do not sum their existing normalized histograms.

The completed random pilot used about 63 summed worker-wall hours for
1,200 events, including startup and I/O. This is measured pilot cost, not a
demonstration of selected-event CPU savings. The comparison's 0.378 weighted
second-moment ratio is conditional on extra sampling of the observed pool;
it does not establish a 2.65-fold improvement in the final physics result.

## Preserved state

No shared release was rebuilt; detector, electronics, trigger and analysis
cuts were kept unchanged. No commit, push, cleanup or campaign deletion was
performed. Temporary study scripts are under
`shift_cmssw_workflow/tmp/20261012-qcd-selection-study/`; diagnostic code
snapshots and hashes are preserved with their results. The unused
`prepare_candidate_gen_pool.py` parent-selector plan must not be launched:
the held-out parent result did not justify it.

`SHIFT_ANALYSIS.md` owns the selection/normalization strategy.
`SHIFT_RECONSTRUCTION.md` owns response and detector validation.
Mixing closure, its absolute normalization and background ownership remain
unfinished analysis requirements.
