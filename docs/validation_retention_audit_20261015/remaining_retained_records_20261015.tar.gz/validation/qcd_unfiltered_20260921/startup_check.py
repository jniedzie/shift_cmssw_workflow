"""Bounded startup evidence only; no mass reads and no completion monitoring."""
from collections import Counter
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess

directory = Path(__file__).resolve().parent
campaigns = []
for sample, jobs, prefix, size in [('qcd', 400, 'QCD_UnfilteredDecays', '100k'),
                                   ('jpsi', 40, 'Jpsi_Unfiltered', '10k')]:
    for bounds in ('1to2', '2to5', '5to10'):
        log = directory / f'submit_{sample}_{bounds}.log'
        text = log.read_text()
        matches = re.findall(r'(\d+) job\(s\) submitted to cluster (\d+)\.', text)
        if len(matches) != 1:
            raise ValueError(f'No unique submission acknowledgement: {log}')
        count, cluster = map(int, matches[0])
        assert count == jobs
        snapshot = re.search(r'^Frozen workflow snapshot: (.+)$', text, re.M).group(1)
        name = f'{prefix}_pThat_{bounds}_ATLASproxy_{size}_20260921_v1'
        root = Path('/eos/home-j/jniedzie/shift_cmssw') / sample / name
        campaigns.append(dict(sample=sample, bin=bounds, cluster=cluster, jobs=jobs,
                              events=250*jobs, campaign=str(root), frozen_workflow=snapshot))

clusters = [str(c['cluster']) for c in campaigns]
result = subprocess.run(['condor_q', *clusters, '-json', '-attributes',
    'ClusterId,ProcId,JobStatus,HoldReason,RemoteHost,RequestMemory,RequestCpus,RequestDisk,MaxRuntime'],
    check=True, capture_output=True, text=True)
queue = json.loads(result.stdout)
for campaign in campaigns:
    rows = [r for r in queue if r['ClusterId'] == campaign['cluster']]
    campaign['queue_status_counts'] = dict(Counter(r['JobStatus'] for r in rows))
    campaign['queue_rows'] = len(rows)
    campaign['held'] = [dict(proc=r['ProcId'], reason=r.get('HoldReason')) for r in rows if r['JobStatus'] == 5]
    campaign['scheduler_resources'] = {key: sorted({r[key] for r in rows})
        for key in ('RequestCpus', 'RequestMemory', 'RequestDisk', 'MaxRuntime')}
    # CERN submission transforms can raise CPU/RAM requests; never accept less.
    assert all(r['RequestCpus'] >= 1 and r['RequestMemory'] >= 4000 and
               r['RequestDisk'] == 10240000 and r['MaxRuntime'] == 50400 for r in rows)
    running = sorted(r['ProcId'] for r in rows if r['JobStatus'] == 2)
    evidence = []
    for proc in running[:3]:
        root = Path(campaign['campaign']) / 'chain_metadata' / f'part{proc:04d}'
        for path in sorted(root.glob('step*_attempt_*.log')):
            try:
                lines = path.read_text(errors='replace').splitlines()
            except OSError as error:
                evidence.append(dict(proc=proc, log=str(path), read_error=str(error),
                                     records_started=0, fatal_exception_markers=[]))
                continue
            progress = [line for line in lines if line.startswith('Begin processing')]
            fatal = [line for line in lines if line.startswith('----- Begin Fatal')]
            evidence.append(dict(proc=proc, log=str(path), bytes=path.stat().st_size,
                                 records_started=len(progress), latest_progress=progress[-1:] or [],
                                 fatal_exception_markers=fatal))
    campaign['startup_evidence'] = evidence
    print(campaign['sample'], campaign['bin'], 'cluster', campaign['cluster'],
          'statuses', campaign['queue_status_counts'],
          'sampled event records started', sum(e['records_started'] for e in evidence),
          'held', len(campaign['held']))

report = dict(checked_at=datetime.now(timezone.utc).isoformat(), campaigns=campaigns,
              stage='startup_only_not_completion', reconstructed_mass_read=False)
(directory / 'submission_status.json').write_text(json.dumps(report, indent=2) + '\n')
