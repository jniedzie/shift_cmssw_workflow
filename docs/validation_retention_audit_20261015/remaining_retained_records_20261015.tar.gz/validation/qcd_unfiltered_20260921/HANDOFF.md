# Overnight QCD and J/psi submission — 2026-09-21

## September 22 recovery submitted

See `RECOVERY_20260922.md` for the current handoff. Exact-chunk matching and
graceful shutdown fixes passed tests. Three GEN count failures were reproduced
and audited using actual generated counts with unchanged seeds. All ten
staged-runtime canaries passed independent end-to-end validation.
Recovery cluster **1960281**, scheduler **bigbird21.cern.ch**, contains exactly
the 326 missing chunks, globally capped at 50 materialized jobs. The 994
successful chunks are excluded; failed chunks' old provenance and abandoned
locks were archived before recovery. No campaign is declared complete yet.
Use `recovery_queue_map.json`: Condor ProcId is NOT the production chunk ID.

## September 22: stopped, incomplete — do not use as merged productions

`terminal_audit_20260922.json` supersedes the startup-only status below.
All 1320 jobs have terminal event-log records. 994 succeeded; 326 failed.
EOS final-file IDs exactly match the zero-exit job IDs. No ROOT payloads were
newly validated and no partial campaign was merged.

Successful chunks: QCD 346/400, 325/400, 257/400; J/psi 36/40, 30/40, 0/40
for 1--2, 2--5, 5--10 respectively. Failures: 201 stale locks after recorded
AFS evictions, 122 ambiguous config/log provenance matches, three Step-1
subprocess failures. Preserve all checkpoints, logs and remaining inputs.
`audit_terminal_logs.py` reproduces this bounded scheduler-independent check.

CERN IT reported high AFS load and a temporary 1206-job account ceiling after
about 1608 concurrent account jobs. Current queue/ceiling cannot be established:
bigbird14 is unavailable and userprio has no user row. There is no need to
cancel these six ended campaigns; do not infer that unrelated jobs are absent.
No jobs were retried and no locks removed during this check.

Before recovery: fix exact chunk provenance matching (the broad wildcard
matches seeds), test multi-chunk and eviction recovery, stage the custom
runtime locally, restore scheduler visibility, and enforce a global cautious
concurrency limit. The workflow generation guide records a proposed 10-worker
canary then 50 concurrent SHIFT workers, subject to available account headroom
and measured load. Do not resume hundreds at once or bypass CERN's ceiling.
Recovery must be limited to the saved missing-ID sets, preserving successful
outputs. Re-audit the complete bins before merging/cross-section publication.

## Resumed and submitted (supersedes the historical pause below)

The user subsequently authorized submission plus startup checks, explicitly
not monitoring to completion, and added a larger J/psi production. All six
clusters were submitted at about 17:06 CERN, well before the user's 17:54:26
deadline. Current queue/startup evidence is in `submission_status.json`.

**Final startup checkpoint, 17:13:14 CERN:** all 1320 submitted jobs remain
in the queue: 1303 running, 17 idle, zero held. Representative workers in
every sample/bin are processing events; no sampled fatal exceptions or
nonempty new-worker stderr files were found. This is startup validation, not
production completion. A separate read-only history query stalled and was
stopped; no history-based completion claim is made. One transient EOS read
error on an actively written log cleared on the subsequent read. All tiny
end-to-end smoke tests were independently validated before launch.
Monitoring stops here as requested. No production job was stopped.

Usage check at 17:14 CERN: 38% weekly used, 62% remaining (37% used at the
start of this final one-hour allowance); no reset credits consumed. Exact
per-task token count is not exposed by the available usage tool.

| Sample | Born pThat | Events | Jobs | Cluster |
| --- | --- | ---: | ---: | ---: |
| QCD | 1--2 | 100000 | 400 | 17392546 |
| QCD | 2--5 | 100000 | 400 | 17392552 |
| QCD | 5--10 | 100000 | 400 | 17392553 |
| J/psi | 1--2 | 10000 | 40 | 17392549 |
| J/psi | 2--5 | 10000 | 40 | 17392551 |
| J/psi | 5--10 | 10000 | 40 | 17392555 |

All jobs process 250 events. Submitted requests were one CPU/4000 MB RAM;
CERN's scheduler transformed them upward to **two CPUs/6000 MB**. Disk remains
10000 MB and maximum runtime 50400 seconds. Runtime estimates are not a
guarantee of overnight completion. The 0--1 prescription remains unresolved;
high-pThat tails are not scaled up here.

EOS roots, with `<bin>` = `1to2`, `2to5`, `5to10`:

- `/eos/home-j/jniedzie/shift_cmssw/qcd/QCD_UnfilteredDecays_pThat_<bin>_ATLASproxy_100k_20260921_v1/`
- `/eos/home-j/jniedzie/shift_cmssw/jpsi/Jpsi_Unfiltered_pThat_<bin>_ATLASproxy_10k_20260921_v1/`

Final per-job files are `samples/step4/events_NanoAOD_part_NNNN.root`.
These are **not yet merged or declared complete**. Per-chunk GEN cross sections
and denominators are preserved in `generation_metadata/partNNNN.json`, even
after Step 1 is retired. At completion combine all expected records with
`collect_generation_metadata.py --expected-chunks 400` (QCD) or `40` (J/psi)
and export `cross_sections_complete.txt`, then use the complete generated-event
denominator with ordinary genWeight. Do not use old sampling sidecars or rely
on the first-worker text estimate. Forced J/psi decay normalization stays
explicitly provisional, as does the ATLAS geometry.

All pending old smokes finished successfully. Final revised QCD and J/psi
two-event full chains passed too. `final_smoke_audit.json` independently
confirms all five smoke outputs, exact IDs/counts, unit weights, retained
provenance and deletion receipts. No reconstructed masses were accessed.
Both combined cross-section export smoke tests passed. Seventeen new
contract/submission/restart tests and 23 related existing tests passed again.
Resolved J/psi channels/decays match the preceding binned pilots; it retains
CMS lifetime settings, not the older fragment's three legacy overrides.

`production.sh` records the exact submission procedure, with a per-bin lock
to prevent accidental duplicate submission. `submit_*.log` retains Condor
acknowledgements and frozen runtime roots. `startup_check.py` performs one
bounded read-only queue/progress check; it is NOT an overnight monitor.
No shared CMSSW build or live frozen workflow edits were performed.

Verbose worker transcripts now go to EOS `chain_metadata/partNNNN/`; AFS
receives short Condor progress only. Snapshots exclude historical Condor log
directories and Python caches; no historical logs or samples were deleted.
AFS had about 252 MiB free after all submissions; EOS had about 589 GB free
before launch. Continue watching quota when merging later.

Tomorrow: inspect queue/history together, audit all exact expected chunk IDs
and final ROOT files, recover only missing/failed chunks from durable
checkpoints, then merge and combine cross sections. Do not clear a hard-kill
`active.lock` unless the old worker is confirmed gone. Never rebuild shared
CMSSW while these campaigns are running.

## Historical pause record

User left on 2026-09-21 and asked whether to submit or pause. Recommendation:
pause large production until the remaining validation and campaign sizing are
settled. **No large campaign or new Condor jobs were submitted.** The sole
Condor operation was `condor_submit -dry-run`; its reported "cluster 1" is a
dry-run placeholder, not a real submitted cluster.

## Implemented, not committed

All changes are on `shift_cmssw_workflow/main`; no shared CMSSW changes/build.
Unrelated J/psi cluster 17387641 still had five running jobs when work began;
they use `validation/sampling_scan_20260921_v10/workflow`, not these changes.
Recheck live queue before any future build; none is needed by this setup.

- New `QCD_UnfilteredDecays_FixedTarget_pThat_1to5GeV_13p6TeV_pythia8_cff.py`:
  no generator-muon filter, no momentum/acceptance preference, no 10% sampling.
  Keeps established long-lived pi/K/KL decay corridor, CMS CP5/common settings,
  source/beam setup and primary-process separation. Historical fragments and
  weighted outputs remain unchanged for reproducibility.
- New `config/campaigns/qcd_unfiltered_2023.env`: choose `QCD_BIN` in a fresh
  shell. Explicit Born boundaries, fresh independent per-bin seed ranges,
  current ATLAS proxy with unchanged timing/detector settings; no pileup/trigger.
  Supports 1--2, 2--5, 5--10, 10--20 and 20--infinity; 0--1 remains blocked.
- Proposed 250 events/job, one CPU, 4000 MB RAM, 10000 MB disk,
  `CONDOR_MAX_RUNTIME_SECONDS=50400`. `N_JOBS` defaults to **one**, not a large
  campaign. Total events/jobs per bin still need to be agreed with the user.
- `WORKFLOW_LOCAL_GENERATOR=1` loads a frozen generator fragment in a temporary
  Python package; cmsDriver inlines it. No shared registration, symlink edits,
  SCRAM build or plugin relink. Use `--prebuilt` when submitting.
- `CLEANUP_PREVIOUS_STEP=1` is opt-in globally, on in the new profile. The full
  Condor worker delegates to `run_retiring_chain.py`: verify published ROOT
  bytes, complete event identities, unit weights, stage products and preserved
  metadata before unlinking the exact predecessor ROOT file. Logs/configs,
  counters, cross sections, resource reports and deletion receipts survive.
  Final output is Step 4 only. Standalone run_step scripts do not perform this
  cleanup. Restricted to this unfiltered, no-pileup/no-trigger, non-forced,
  ungrouped full chain; other modes fail preflight.
- Durable checkpoints resume from the last validated stage, without
  regenerating retired predecessors. Missing/corrupt latest output or changed
  provenance stops. A hard-killed process can leave an `active.lock`: verify
  the old worker is gone before clearing that exact lock. Never auto-delete a
  live/unknown lock. No --force with cleanup.
- Generator audit accepts/checks explicit Born bounds, all attempt/pass counts
  and exact IDs; metadata collector rejects mixed bins and can export a
  combined `cross_sections_complete.txt`. Ordinary genWeight and complete-event
  denominator apply to NEW samples. Old weighted replays are still weighted.
- Real Condor dry-run support added to `run_condor.sh --dry-run /absolute/file`.
  New generator/cleanup/seed variables are pinned in the submit environment.

## Validation completed

- 54 focused tests passed: 12 unfiltered chain/retirement/restart tests,
  19 sampling/weighted/merge tests, 6 fixed-target tests, 8 QCD tests,
  2 cross-section export tests, 7 Step-4/preflight tests. Shell syntax checks
  and `git diff --check` passed. Checkpoint tests include failed Step 3,
  corrupted latest output, missing config provenance, and no regeneration
  after successful cleanup. They do not replace live ROOT validation.
- First live unfiltered full-chain smoke: 1--2 GeV, four events, all four
  stages succeeded, attempted=saved=4, unit weights, filter efficiency 1.
  Step 1/2/3 ROOT files were removed only after successful successor checks;
  only Step 4 remains. Configs/logs/GEN metadata retained. No mass values read.
  Stage wall seconds: 146.8, 26.0, 57.9, 90.8. Largest recorded peak RSS:
  3047080 kB (about 2.9 GiB). Resolved config contains only generator in
  ProductionFilterSequence and correct explicit 1--2 bounds.
- Repeating `smoke.sh 1to2 4` validated the completed checkpoint without
  rerunning any stage (`resume_1to2.log`).
- Actual Condor dry run passed with 250 events, RequestCpus=1,
  RequestMemory=4000, RequestDisk=10240000 kB, MaxRuntime=50400.
  Evidence: `dry_run.log`, `condor_1to2.ad`. The ad includes inherited
  environment; do not print the whole environment or capability URLs in logs.
- Runtime estimate from 128 old QCD jobs: mean stage seconds/event 77, 81,
  107; maximum 148. Thus 250 events is roughly 5.4--7.4 h at bin means and
  10.3 h at the slowest observed rate, before extra audits/I/O. Old Condor
  maximum MemoryUsage was 2686 MB. **No full 250-event unfiltered benchmark
  has run.** Job size and overnight completion are estimates, not guarantees.

## Still running at pause

Two tiny local smoke chains, NOT Condor production:

- `smoke_2to5.log`: two events, Steps 1--3 completed and Step 4 running.
  Tool session 72517.
- `smoke_5to10.log`: two events, Steps 1--3 completed and Step 4 running.
  Tool session 17869.

Both use the immutable snapshot:
`shift_cmssw_workflow/condor/runtime_snapshots/QCD_UnfilteredDecays_pThat_1to2_ATLASproxy_2023_v1/20260921T144313Z-655618`.
They may finish after this note. Check final log status and durable output,
not only process disappearance. They exercise only their own new smoke
campaigns' cleanup; no historical sample is deleted.

All three smoke campaign roots are:
`/eos/home-j/jniedzie/shift_cmssw/qcd/QCD_UnfilteredDecays_pThat_<bin>_ATLASproxy_smoke_20260921_v1/`.
Inspect `chain_metadata/part0000/state.json`, deletion receipts, retained
`configs/`, `logs/`, `generation_metadata/part0000.json` and
`samples/step4/events_NanoAOD_part_0000.root`. Read only IDs/weights/topology
counts, never reconstructed masses.

## Resume checklist before submission

1. Confirm both pending smoke chains finished normally. Independently reopen
   all three final ROOT files; check IDs, counts, unit weights, saved metadata
   and hashes. Confirm only Step 4 remains and all provenance survives.
2. The main helper gained an additional retained config/log hash check after
   the first snapshot, and the metadata collector gained combined text export.
   Unit tests pass, but re-run completed smoke checkpoint validation using the
   current helper and test the new combined cross-section CLI on smoke metadata.
   Make a fresh final dry-run snapshot/ad after all edits; do not edit the
   running test snapshot or treat the first dry-run snapshot as final code.
3. Add direct submission-preflight tests for invalid resource/count values and
   cleanup with unsupported --steps/--force. Inspect the final parsed ad's
   selected environment keys (not the full inherited environment), including
   bounds, cleanup flag and independent seeds. Check supported other-bin
   preflights. High-pThat 10--20 and 20--infinity have no unfiltered runtime
   sizing/smoke yet; do not assume the first three bins' timing covers them.
4. Review safe-retirement code and docs one final time; verify no temporary
   paths remain in archived resolved configs. A hard-kill stale-lock recovery
   requires explicit operator verification; record that operational limitation.
5. Agree total events/jobs per bin and prioritize bins with the user. Recheck
   queue, EOS quota, metadata/log growth and available batch capacity. A
   14-hour per-job limit does not guarantee an entire large campaign overnight.
   Keep 0--1 production gated on its physics prescription. The current geometry
   is still ATLAS proxy, not CMS IR5.
6. Submit only with the user's production decision. Use a fresh shell/profile
   per bin, explicit N_JOBS, frozen runtime, `--prebuilt --keep-logs`.
   Do not modify the old analysis input paths or weighted samples automatically.

Canonical project status: `SHIFT_ANALYSIS.md`. Usage details:
`shift_cmssw_workflow/docs/generation_instructions.md`, section
"Unfiltered QCD production". No commits were requested or made this turn.
