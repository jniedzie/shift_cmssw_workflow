"""Generate capped single-cluster submissions; this script never submits."""
import hashlib
from pathlib import Path
import shutil

directory = Path(__file__).resolve().parent
workspace = directory.parents[1]
archive = Path('/eos/home-j/jniedzie/shift_cmssw/production_recovery/20260922_v1/payload.tar.gz')
checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
bootstrap = directory / 'frozen_recovery_bootstrap.sh'
if bootstrap.exists():
    raise ValueError('Refusing to replace frozen bootstrap')
shutil.copy2(workspace/'shift_cmssw_workflow/scripts/run_staged_recovery.sh',bootstrap)
bootstrap.chmod(0o555)
url = 'root://eosuser.cern.ch//eos/user/j/jniedzie/shift_cmssw/production_recovery/20260922_v1/payload.tar.gz'
for kind,count,limit in [('canary',10,10),('recovery',326,50)]:
    logs = directory/f'{kind}_condor_logs'
    logs.mkdir(exist_ok=True)
    text = f'''universe = vanilla
executable = {bootstrap}
arguments = "{url} {checksum} {kind}_manifest.json $(Process) $(ClusterId).$(Process)"
initialdir = {directory}
getenv = False
should_transfer_files = YES
when_to_transfer_output = ON_EXIT
transfer_output_files = ""
request_cpus = 2
request_memory = 6000 MB
request_disk = 12000 MB
+MaxRuntime = 50400
+JobBatchName = "SHIFT_{kind}_20260922_v1"
+ShiftRecovery = True
max_materialize = {limit}
max_idle = {limit}
on_exit_hold = (ExitBySignal == True) || (ExitCode != 0)
output = {logs}/$(ClusterId).$(Process).out
error = {logs}/$(ClusterId).$(Process).err
log = {logs}/$(ClusterId).log
queue {count}
'''
    with (directory/f'{kind}.sub').open('x') as stream:
        stream.write(text)
    print(kind,count,'jobs; global materialized limit',limit)
