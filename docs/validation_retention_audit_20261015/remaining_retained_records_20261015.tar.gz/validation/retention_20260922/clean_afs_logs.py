"""One-off authorized cleanup: exact inactive AFS Condor log files only."""
import argparse
from collections import Counter
import json
from pathlib import Path
import re
import stat
import subprocess
import time

WORKSPACE = Path('/afs/cern.ch/work/j/jniedzie/private/shift_cmssw')
ROOT = WORKSPACE / 'shift_cmssw_workflow/condor/logs'
REPORT = Path(__file__).resolve().parent

def queue():
    result = subprocess.run(['condor_q', '-global', '-constraint', 'Owner == "jniedzie"',
        '-json', '-attributes', 'ClusterId,ProcId,JobStatus,Out,Err,UserLog,Cmd,Iwd,Args'],
        capture_output=True, text=True, timeout=45, check=True)
    if result.stderr.strip():
        raise RuntimeError('Scheduler warning; refusing cleanup: ' + result.stderr)
    jobs = json.loads(result.stdout)
    # A separate tau job appeared during the audit. Its script/config were read:
    # inputs/outputs are under mono_cmssw, not any SHIFT retirement target.
    for j in jobs:
        if j['ClusterId'] == 1960281:
            continue
        if (j['ClusterId'] == 17432196 and j.get('Cmd') == '/usr/bin/python3'
            and j.get('Iwd') == '/afs/cern.ch/work/j/jniedzie/private/mono_cmssw_production'
            and j.get('Args', '').startswith('/afs/cern.ch/work/j/jniedzie/private/mono_cmssw_production/scripts/run_tautau_chunk.py ')):
            continue
        raise RuntimeError('Unexpected live campaign; refresh dependency review')
    for j in jobs:
        if any(str(j.get(k, '')).startswith(str(ROOT) + '/') for k in ('Cmd','Out','Err','UserLog','Iwd')):
            raise RuntimeError('Live job uses cleanup directory')
    return jobs

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--apply', action='store_true')
    args = p.parse_args()
    jobs = queue()
    active = {j['ClusterId'] for j in jobs}
    candidates = []
    skipped = []
    for path in sorted(ROOT.rglob('*')):
        s = path.lstat()
        if stat.S_ISDIR(s.st_mode):
            continue
        if not stat.S_ISREG(s.st_mode) or path.resolve() != path:
            raise RuntimeError(f'Unexpected non-regular file: {path}')
        match = re.fullmatch(r'condor_(\d+)(?:\.\d+)?\.(out|err|log)', path.name)
        if not match or int(match[1]) in active:
            skipped.append(str(path))
            continue
        candidates.append(dict(path=str(path), size=s.st_size, mtime_ns=s.st_mtime_ns, inode=s.st_ino))
    report = dict(created=time.time(), queue=jobs, files=candidates, skipped=skipped,
                  bytes=sum(r['size'] for r in candidates), no_backup_by_user_request=True)
    dest = REPORT / ('afs_delete_manifest.json' if args.apply else 'afs_preview.json')
    with dest.open('x') as f:
        json.dump(report, f, indent=2)
    print('Candidate files:', len(candidates), 'bytes:', report['bytes'], 'skipped:', len(skipped), flush=True)
    if not args.apply:
        return
    queue()
    count = 0
    total = 0
    with (REPORT / 'afs_deleted.jsonl').open('x') as receipt:
        for r in candidates:
            path = Path(r['path'])
            s = path.lstat()
            if not stat.S_ISREG(s.st_mode) or (s.st_size,s.st_mtime_ns,s.st_ino) != (r['size'],r['mtime_ns'],r['inode']):
                raise RuntimeError(f'File changed after inventory: {path}')
            path.unlink()
            receipt.write(json.dumps(r) + '\n')
            count += 1
            total += r['size']
            if count % 1000 == 0:
                receipt.flush()
                print('Deleted', count, 'files', flush=True)
    with (REPORT / 'afs_result.json').open('x') as f:
        json.dump(dict(files=count,bytes=total,skipped=skipped,finished=time.time()), f, indent=2)
    print('Removed', count, 'inactive logs;', total, 'bytes. Current recovery logs untouched.', flush=True)

if __name__ == '__main__':
    main()
