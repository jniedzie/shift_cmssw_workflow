#!/usr/bin/env bash
set -eo pipefail
workspace=/afs/cern.ch/work/j/jniedzie/private/shift_cmssw
source /cvmfs/cms.cern.ch/cmsset_default.sh
cd "$workspace/CMSSW_17_0_0_pre4/src"
eval "$(scram runtime -sh)"
export TMPDIR=/tmp/jniedzie
python3 "$workspace/shift_cmssw_workflow/scripts/merge_sampling_replay.py" \
  "$workspace/validation/sampling_scan_20260921_v10/replay_manifest.json" \
  --audit-directory "$workspace/validation/qcd_weighted_merges_20260921"
