"""Scheduler-independent terminal inventory; never reads event payloads."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

directory = Path(__file__).resolve().parent
workspace = directory.parents[1]
manifest = json.loads((directory / 'submission_status.json').read_text())
report = dict(checked_at=datetime.now(timezone.utc).isoformat(),
              source='retained Condor event/stderr logs and EOS final-file inventory',
              scheduler_current_state='unavailable; bigbird14 address not found',
              reconstructed_mass_read=False, root_payload_validation=False,
              merged=False, campaigns=[])
for campaign in manifest['campaigns']:
    root = Path(campaign['campaign'])
    logs = workspace / 'shift_cmssw_workflow/condor/logs' / root.name
    event_log = logs / f'condor_{campaign["cluster"]}.log'
    text = event_log.read_text()
    last = {}
    afs_evictions = set()
    for record in re.split(r'(?m)(?=^\d{3} \()', text):
        match = re.match(r'(\d{3}) \((\d+)\.(\d+)\.\d+\)', record)
        if not match:
            continue
        code, cluster, proc = map(int, match.groups())
        if cluster != campaign['cluster']:
            raise ValueError('Wrong cluster in event log')
        last[proc] = (code, record)
        if 'Vacated by StackStorm due to high AFS usage' in record:
            afs_evictions.add(proc)
    expected = set(range(campaign['jobs']))
    assert set(last) == expected and all(code == 5 for code, _ in last.values())
    exits = {}
    failures = {}
    for proc, (_, record) in last.items():
        exits[proc] = int(re.search(r'Normal termination \(return value (\d+)\)', record)[1])
        if exits[proc]:
            error = (logs / f'condor_{campaign["cluster"]}.{proc}.err').read_text()
            if 'Missing or ambiguous stage config/log provenance' in error:
                failures[proc] = 'ambiguous_provenance_glob'
            elif 'FileExistsError' in error and 'active.lock' in error:
                failures[proc] = 'abandoned_lock_after_restart'
            elif 'CalledProcessError' in error:
                failures[proc] = 'stage_subprocess_failed'
            else:
                failures[proc] = 'other_failure'
    files = {int(p.stem.rsplit('_', 1)[1]): p for p in
             (root / 'samples/step4').glob('events_NanoAOD_part_*.root')}
    successful = {proc for proc, code in exits.items() if code == 0}
    assert set(files) == successful
    locked = {proc for proc, kind in failures.items() if kind == 'abandoned_lock_after_restart'}
    result = dict(sample=campaign['sample'], bin=campaign['bin'], cluster=campaign['cluster'],
                  campaign=str(root), expected_jobs=campaign['jobs'],
                  successful_jobs=len(successful), failed_jobs=len(failures),
                  final_file_ids=sorted(files), missing_final_ids=sorted(expected-set(files)),
                  failures_by_chunk=failures, failure_counts=dict(Counter(failures.values())),
                  afs_evicted_ids=sorted(afs_evictions),
                  all_lock_failures_have_recorded_afs_eviction=locked <= afs_evictions,
                  all_jobs_have_terminal_records=True, merge_ready=False,
                  event_log=str(event_log), event_log_sha256=hashlib.sha256(text.encode()).hexdigest())
    report['campaigns'].append(result)
    print(campaign['sample'], campaign['bin'], len(successful), '/', len(expected),
          result['failure_counts'], 'AFS-evicted', len(afs_evictions), flush=True)
(directory / 'terminal_audit_20260922.json').write_text(json.dumps(report, indent=2) + '\n')
