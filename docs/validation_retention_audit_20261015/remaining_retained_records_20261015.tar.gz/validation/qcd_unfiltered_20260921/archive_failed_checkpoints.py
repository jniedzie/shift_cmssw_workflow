"""Archive failed-chunk locks/provenance only after proof that old jobs ended."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

directory = Path(__file__).resolve().parent
workspace = directory.parents[1]
sys.path.insert(0, str(workspace/'shift_cmssw_workflow/scripts'))
from run_retiring_chain import sha

audit = json.loads((directory/'terminal_audit_20260922.json').read_text())
manifest = json.loads((directory/'recovery_manifest.json').read_text())
clusters = [str(c['cluster']) for c in audit['campaigns']]
query = subprocess.run(['condor_q','-name','bigbird14.cern.ch',*clusters,'-json',
                        '-attributes','ClusterId,ProcId,JobStatus'],
                       check=True,capture_output=True,text=True,timeout=25)
if 'ERROR' in query.stderr.upper():
    raise ValueError('Scheduler query reported an error')
# This installed Condor emits an empty string, rather than [], for zero rows.
if json.loads(query.stdout.strip() or '[]'):
    raise ValueError('Original jobs still exist; refusing to touch their locks')
for campaign in audit['campaigns']:
    if sha(campaign['event_log']) != campaign['event_log_sha256']:
        raise ValueError('Original terminal log changed; refresh the audit')
    assert campaign['all_jobs_have_terminal_records']

archived = []
for row in manifest['jobs']:
    campaign = Path(row['campaign'])
    part = f'{row["chunk"]:04d}'
    if (campaign/'samples/step4'/f'events_NanoAOD_part_{part}.root').exists():
        raise ValueError('Chunk acquired a final output; do not touch it')
    directory_chunk = campaign/'chain_metadata'/f'part{part}'
    directory_chunk.mkdir(parents=True,exist_ok=True)
    archive = directory_chunk/'recovery_before_20260922_v1'
    if archive.exists():
        raise ValueError('Archive already exists; do not repeat this one-time operation')
    archive.mkdir()
    receipt = dict(original_cluster=row['old_cluster'],chunk=row['chunk'],
                   original_jobs_absent=True,terminal_log_verified=True,files={})
    for original in [directory_chunk/'state.json',
                     campaign/'generation_metadata'/f'part{part}.json']:
        if original.exists():
            target=archive/('generation_metadata.json' if original.name.startswith('part') else original.name)
            shutil.copy2(original,target)
            receipt['files'][str(original)]=sha(target)
    import re
    pattern = re.compile(rf'_part_?{row["chunk"]:04d}(?:_|\.)')
    for stage in range(1,5):
        for parent,glob in [(campaign/'configs'/f'step{stage}','*_cfg.py'),
                            (campaign/'logs',f'step{stage}_*.log')]:
            for original in parent.glob(glob):
                if not pattern.search(original.name):continue
                target=archive/original.name
                shutil.copy2(original,target)
                receipt['files'][str(original)]=sha(target)
    lock=directory_chunk/'active.lock'
    receipt['lock_archived']=lock.exists()
    if lock.exists():
        lock.rename(archive/'abandoned_active.lock')
    (archive/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    archived.append(dict(campaign=str(campaign),chunk=row['chunk'],lock_archived=receipt['lock_archived']))
    if len(archived)%50==0: print('Archived',len(archived),'failed chunks',flush=True)
(directory/'checkpoint_archive_report.json').write_text(json.dumps(archived,indent=2)+'\n')
print('Archived',len(archived),'failed chunks;',sum(x['lock_archived'] for x in archived),'locks retained, not deleted')
