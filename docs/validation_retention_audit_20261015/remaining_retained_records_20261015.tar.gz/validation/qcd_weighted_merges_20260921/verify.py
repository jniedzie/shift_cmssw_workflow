"""Independent published-artifact audit; never enable any mass branch."""
import hashlib
import json
import math
from pathlib import Path
import sys

workspace = Path('/afs/cern.ch/work/j/jniedzie/private/shift_cmssw')
sys.path.insert(0, str(workspace / 'shift_cmssw_workflow/scripts'))
from merge_sampling_nano import inspect

directory = Path(__file__).resolve().parent
summaries = {g['campaign']: g for g in json.loads((directory / 'summary.json').read_text())['groups']}
results = []
for merge in json.loads((directory / 'merges.json').read_text()):
    output = Path(merge['output'])
    assert json.loads(output.with_suffix('.json').read_text()) == merge
    assert hashlib.sha256(output.read_bytes()).hexdigest() == merge['sha256']
    for sidecar in merge['sidecars'].values():
        assert hashlib.sha256(Path(sidecar['path']).read_bytes()).hexdigest() == sidecar['sha256']
    rows, schema = inspect(output)
    assert schema == merge['schema_sha256']
    campaign = output.parents[2]
    weights = [json.loads(line) for line in (campaign / 'sampling_weights.jsonl').read_text().splitlines()]
    keyed = {tuple(w['id']): w for w in weights}
    assert len(keyed) == len(weights) == merge['events']
    assert keyed.keys() == rows.keys()
    norm = json.loads((campaign / 'cross_sections.json').read_text())
    parent = json.loads(Path(norm['parent_report']).read_text())
    sigma = parent['generation']['runs'][0]['internal_xsec_pb']
    attempts = parent['contract']['attempted_events']
    assert attempts == norm['unique_parent_attempts'] == 5000
    weighted = dict(events=0., events_muon=0., events_vertex=0., events_both_both=0.)
    weighted_pb = {key: 0. for key in weighted}
    for identity, reco in rows.items():
        w = keyed[identity]
        assert math.isclose(w['sampling_weight'] * w['sampling_probability'], 1.)
        assert math.isclose(w['event_weight_pb'], sigma / attempts * w['sampling_weight'])
        for key, passes in [('events', True), ('events_muon', reco['muons'] > 0),
                            ('events_vertex', reco['vertices'] > 0), ('events_both_both', reco['both_both'] > 0)]:
            if passes:
                weighted[key] += w['sampling_weight']
                weighted_pb[key] += w['event_weight_pb']
    assert weighted == summaries[merge['campaign']]['weighted_counts']
    results.append(dict(campaign=merge['campaign'], output=str(output), events=len(rows),
                        before_filter_pb=sigma, weighted_counts=weighted, weighted_cross_sections_pb=weighted_pb,
                        status='validated', reconstructed_mass_read=False))
    print(merge['campaign'], len(rows), 'events; cross section', sigma, 'pb; weights and hashes validated')
(directory / 'published_audit.json').write_text(json.dumps(results, indent=2) + '\n')
