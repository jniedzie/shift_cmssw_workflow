#!/usr/bin/env bash
# One invocation per fresh shell; never rebuild or remove historical logs.
set -eo pipefail
workspace=/afs/cern.ch/work/j/jniedzie/private/shift_cmssw
workflow=$workspace/shift_cmssw_workflow
sample=${1:?sample}; bin=${2:?bin}; mode=${3:?check, dry-run or submit}
case "$bin" in 1to2|2to5|5to10) ;; *) exit 2 ;; esac
source /cvmfs/cms.cern.ch/cmsset_default.sh
set -a
N_EVENTS=250
CMSSW_SRC=$workspace/CMSSW_17_0_0_pre4/src
SAMPLE_BASE=/eos/home-j/jniedzie/shift_cmssw
case "$sample" in
  qcd)
    QCD_BIN=$bin
    N_JOBS=400
    CAMPAIGN_NAME=QCD_UnfilteredDecays_pThat_${bin}_ATLASproxy_100k_20260921_v1
    source "$workflow/config/campaigns/qcd_unfiltered_2023.env"
    ;;
  jpsi)
    JPSI_BIN=$bin
    N_JOBS=40
    CAMPAIGN_NAME=Jpsi_Unfiltered_pThat_${bin}_ATLASproxy_10k_20260921_v1
    source "$workflow/config/campaigns/jpsi_unfiltered_2023.env"
    ;;
  *) exit 2 ;;
esac
set +a
cd "$workflow"
case "$mode" in
  check) bash run_condor.sh --check ;;
  dry-run) bash run_condor.sh --dry-run "$workspace/validation/qcd_unfiltered_20260921/final_${sample}_${bin}.ad" ;;
  submit)
    marker=$workspace/validation/qcd_unfiltered_20260921/submitted_${sample}_${bin}.lock
    mkdir "$marker" # Refuse accidental duplicate submission, including unknown outcomes.
    bash run_condor.sh --prebuilt --keep-logs
    ;;
  *) exit 2 ;;
esac
