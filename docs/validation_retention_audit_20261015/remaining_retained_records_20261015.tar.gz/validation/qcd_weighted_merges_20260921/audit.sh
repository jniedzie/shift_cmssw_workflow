#!/usr/bin/env bash
set -eo pipefail
workspace=/afs/cern.ch/work/j/jniedzie/private/shift_cmssw
validation="$workspace/validation/qcd_weighted_merges_20260921"
scripts="$workspace/shift_cmssw_workflow/scripts"
manifest="$workspace/validation/sampling_scan_20260921_v10/replay_manifest.json"
source /cvmfs/cms.cern.ch/cmsset_default.sh
cd "$workspace/CMSSW_17_0_0_pre4/src"
eval "$(scram runtime -sh)"
export TMPDIR=/tmp/jniedzie
python3 "$scripts/summarize_sampling_replay.py" "$manifest" --output "$validation/summary.json"
python3 "$scripts/write_sampling_bookkeeping.py" "$manifest" --output "$validation/bookkeeping.jsonl"
python3 "$scripts/audit_sampling_stage_identities.py" "$validation/summary.json" --output "$validation/four_stage_audit.json"
python3 "$scripts/audit_sampling_replay_counts.py" "$manifest" "$validation/bookkeeping.jsonl" --output "$validation/bookkeeping_audit.json"
