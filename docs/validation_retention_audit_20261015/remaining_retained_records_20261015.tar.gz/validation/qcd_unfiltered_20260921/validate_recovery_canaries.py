"""Require all ten staged-runtime canaries; read only allowed Nano columns."""
import hashlib
import json
from pathlib import Path
import sys

directory=Path(__file__).resolve().parent
workspace=directory.parents[1]
sys.path.insert(0,str(workspace/'shift_cmssw_workflow/scripts'))
from run_retiring_chain import inspect, sha, validate_provenance

rows=json.loads((directory/'canary_manifest.json').read_text())['jobs']
reports=[]
for row in rows:
    root=Path(row['campaign'])
    part=f'{row["chunk"]:04d}'
    directory_chunk=root/'chain_metadata'/f'part{part}'
    state=json.loads((directory_chunk/'state.json').read_text())
    if set(state['stages']) != {'1','2','3','4'} or (directory_chunk/'active.lock').exists():
        raise ValueError(f'Canary chunk {part} not finished')
    validate_provenance(state)
    metadata=root/'generation_metadata'/f'part{part}.json'
    assert sha(metadata)==state['generation_metadata_sha256']
    gen=json.loads(metadata.read_text())
    assert gen['events']==gen['attempted_events']==gen['framework_requested_events']==2
    assert gen['generator_filter']=='none' and gen['generated_filter_efficiency']==1
    actual=inspect(Path(state['stages']['4']['output']['path']),4)
    assert actual==state['stages']['4']['output']
    assert actual['event_ids']==gen['event_ids']
    for stage in (1,2,3):
        assert not Path(state['stages'][str(stage)]['output']['path']).exists()
        assert json.loads((directory_chunk/f'retired_step{stage}.json').read_text())['status']=='deleted'
    reports.append(dict(sample=row['sample'],bin=row['bin'],chunk=row['chunk'],events=2,
                        output=actual,all_four_stages_validated=True))
    print('Validated staged canary',row['sample'],row['bin'],row['chunk'],flush=True)
with (directory/'canary_validation.json').open('x') as stream:
    json.dump(dict(status='validated',canaries=reports,reconstructed_mass_read=False),stream,indent=2)
print('All ten canaries validated: 20 events, unit weights, safe cleanup, no mass reads')
