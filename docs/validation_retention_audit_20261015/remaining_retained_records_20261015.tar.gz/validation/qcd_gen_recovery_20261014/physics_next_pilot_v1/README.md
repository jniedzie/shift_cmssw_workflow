<!-- Code style: AI-code. AI-generated independent physics review record. -->

The five completed ordinary native blocks contain 100,000 full attempts and
56,311 accepted original collisions. Their actual first-hard-process records
give bottom 2.24065 ± 0.79612 pb and charm 3.00232 ± 0.78947 pb. The corresponding
enriched source gives 2.72798 ± 0.28393 pb and 2.33227 ± 0.16094 pb **before**
weak-decay and orientation corrections. The old bottom-rate warning no longer
appears in this larger reference. This is agreement of integrated source rates;
it does not establish the complete sampling density, detector response or a
tail normalization. The ordinary bottom reference still has only 7.92 effective
originals. All errors use the full attempted denominator, with zero-output
trials included. The ordinary 40k figure is a subset of the 100k.

The independent recomputation checks every recorded original, each block's
rate and sampling error, unique IDs, full trial counts, the native library and
disabled extra proposals. It records previous actual ROOT audit hashes rather
than claiming a fresh ROOT reread. All numerical inputs and source/proposal
seeds are pinned in `first_hard_rate_comparison.json`. The final PDF is in
`tea_shift_cmssw/plots/qcd_tail_recovery_20261014/first_hard_rate_comparison.pdf`;
its input, utility and output hashes are in `rate_comparison_plot_receipt.json`.

The next source packet contains 42 different original collisions: 18 ordinary
and 24 enriched. Every accepted original in each alternative source has positive
detector sampling probability. The two fresh seeds and rule were written before
the hash decisions. Each full probability ledger is retained. The ordinary score
uses the original first-hard heavy class and native weight; the enriched score
uses only audited GEN tail support and its corrected source weight. Neither uses
reconstructed outcomes. These are alternative QCD20+ estimates with their own
100k/20k exposures. They must never be added together or multiplied by old PPS or
night union corrections. All repeated response variants remain one original
collision group.

`detector_pilot_plan.json` is a concrete selection and validation packet. It is
not a runnable deployment and no detector job from it was submitted. Complete
graph export, native decay/orientation receipts, exact Double correction fields,
resolved fixed detector configuration, correct incoming-hadron transport and
whole-cohort outcome accounting are explicit gates. The new 42 graphs are not
needed for the cheaper current check: all four predeclared original GEN mass
above 20 cases are being replayed from retained AOD with the tested Step3 cleaner
off/on under `four_mass_cleaner_replay_v1/`.

The broader saved-GEN pool has 140,292 unused originals with an energetic
undecayed muon parent and no existing muon, with native effective count 2,599
before decay, daughter pointing, material survival and reconstruction. It is
worth scouting independent parent states. It is not 2,599 accepted tail events.
Allocation across QCD bins must use full process exposures and decay/acceptance
information; a maximum parent-pT clue alone is insufficient.

The before-cuts study retains 118 Both-Both combinations before the late cuts
and 113 stored pairs. It does not expose an orders-of-magnitude reservoir.
Earlier direction losses change the available mass/pT shapes, and fitted mass
is not the same as GEN mass. A constant efficiency multiplying the unrestricted
GEN tail is unsupported. The mixing check also remains unvalidated: its
low-mass Both-Both ratios are roughly 2.5–2.8 overall and 3–3.7 in the test sample,
with wide uncertainties and frequent loss of same-sign control support. Only
two allowed mixed OS pairs reach above 70 GeV, sharing one extreme muon; none
reach 80 GeV. Mixing cannot presently supply the needed QCD tail or its rate.

No rate, analysis release or BDT readiness is claimed here. Root owns canonical
findings in SHIFT_ANALYSIS.md and SHIFT_RECONSTRUCTION.md.
