# Complete unfiltered samples, September 23

September 29 retention update: the 1,320 source ROOT chunks below were
explicitly retired, alongside 1,522 listed old diagnostic ROOT payloads.
All compact merged references, normalization and provenance are unchanged;
merged hashes and event counts were revalidated after deletion. The old
HardQCD/standalone J/psi samples remain historical references and must not be
combined with the new common SoftMPI bins. Do not resume their source chunks.
See `../production_plan_20260929/retirement_20260929/result.json` and the
exact manifest/receipts in that directory.

At merging on September 23, all 1,320 expected chunks were validated and merged. All 326 recovery jobs
exited successfully; the recovery queue and factory are empty. Every source
passed checkpoint/config/log hashes, exact generated-event IDs, unit genWeight,
common schema and retirement-receipt checks. Each merged union was verified
locally and independently reopened on EOS. No reconstructed mass was read.
Source chunks and existing first-worker cross-section files were not modified.

## Copyable analysis settings

The user's analysis configurations were not edited. Replace the old sample
patterns and cross-section values with these only for historical comparisons:

```python
base_path = "/eos/home-j/jniedzie/shift_cmssw/"
pt_bins = ["1to2", "2to5", "5to10"]
jpsi_campaign_base = "Jpsi_Unfiltered_pThat_{}_ATLASproxy_10k_20260921_v1"
qcd_campaign_base = "QCD_UnfilteredDecays_pThat_{}_ATLASproxy_100k_20260921_v1"
cross_sections = {  # pb; combined estimates from all chunks
    "jpsi": {
        "1to2": 621357.8611509507,
        "2to5": 116404.48317891415,
        "5to10": 2030.7448141130817,
    },
    "qcd": {
        "1to2": 36563971991.23754,
        "2to5": 3655743759.3925757,
        "5to10": 40792126.38657331,
    },
}
```

Each campaign has exactly one ROOT file in
`<base_path>/<jpsi-or-qcd>/<campaign>/samples/step4_merged/`.
Exact full paths are in [ready_samples.json](ready_samples.json).

| pThat bin (GeV) | J/psi events | QCD events |
| --- | ---: | ---: |
| 1--2 | 10,000 | 100,000 |
| 2--5 | 10,000 | 99,998 |
| 5--10 | 10,000 | 99,999 |

Filenames are `ntuple_complete_<actual_events>events_20260923.root`.
The three-event shortfall comes from previously documented Pythia failed
framework slots, not missing jobs or acceptance filtering.

## Normalization and limitations

Each campaign contains `normalization_complete.json` and
`cross_sections_complete.txt`. Use these combined values, not the retained
first-worker `cross_sections.txt` or old hard-coded sampling/replay values.
Fill with ordinary genWeight and scale by the combined cross section divided
by the actual generated-event count above. No 10% sampling correction or
extra muon-filter efficiency is required. Luminosity is not assumed.
Do not stack old overlapping process estimates as additional independent
physics components; these settings select the new unfiltered samples only.

These remain ATLAS-proxy, no-pileup/no-trigger machinery samples. The 0--1 GeV
bin remains unresolved. Absolute J/psi forced-decay branching conventions and
CMS geometry/trigger physics qualification remain gated; do not add a branching
factor without auditing that convention. `physics_valid=false` and
`normalization_ready=false` retain those physical qualification gates, despite
the completed mechanical normalization and merge checks.

Per-bin audit JSONs and hadd logs are in this directory; each ROOT also has
an adjacent audit JSON. `scheduler_audit.json` records the final job audit.
The reusable helper is `shift_cmssw_workflow/scripts/merge_unfiltered_production.py`;
its four focused tests and 21 related QCD/retirement tests passed before use.
