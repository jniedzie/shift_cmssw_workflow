#!/usr/bin/env bash
set -eo pipefail
workspace=/afs/cern.ch/work/j/jniedzie/private/shift_cmssw
workflow=${SMOKE_WORKFLOW_ROOT:-$workspace/shift_cmssw_workflow}
source /cvmfs/cms.cern.ch/cmsset_default.sh
set -a
QCD_BIN=${1:-1to2}
N_EVENTS=${2:-4}
CAMPAIGN_NAME=QCD_UnfilteredDecays_pThat_${QCD_BIN}_ATLASproxy_${SMOKE_TAG:-smoke_20260921_v1}
GENERATOR_SEED=41000000
SIMULATION_SEED=51000000
CMSSW_SRC=$workspace/CMSSW_17_0_0_pre4/src
SAMPLE_BASE=/eos/home-j/jniedzie/shift_cmssw
source "$workflow/config/campaigns/qcd_unfiltered_2023.env"
source "$workflow/config/workflow.env"
set +a
bash "$workflow/scripts/run_condor_job.sh" 0 \
  "$workflow" 1,2,3,4 0 "$PROCESS" "$SAMPLE_NAME" \
  "$CAMPAIGN_NAME" "$SAMPLE_BASE" "$SAMPLE_DIR" "$N_EVENTS"
