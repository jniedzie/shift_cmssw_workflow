# QCD event-selection checks, 2026-10-12

The geometry feature is a cheap clue for choosing events to reconstruct. It
projects original stable muons or muon-producing parents onto actual CSC
chamber planes and counts stations crossed on each endcap. It does not change
the detector, electronics, trigger or reconstruction.

The export uses Run3_2023 and the production conditions,
`150X_mcRun3_2023_realistic_v2`. It contains 3,672 CSC layers. The score uses
540 unique chamber planes at layer 3; the duplicate ME1/a envelope is removed.
The temporary export plugin was built in the task directory. The shared
CMSSW release was not rebuilt or changed. Twelve geometry tests passed.

The original-parent score did not show a useful gain in the held-out
comparison. It remains a failed selection candidate. The next useful check
uses the actual daughters after natural decays, before detector transport.
Both approaches omit magnetic bending, material and detector response from
their cheap geometry score. Every event group must keep a nonzero chance of
being reconstructed. These scores are not acceptance corrections.

`outlier_replay_review.json` records an independent review of the two exact
V10 diagnostic repeats. Ten tests passed. The event slices, templates,
runtime, decay settings and seeds match their original jobs. Failure markers
and SIM/AOD readback hashes were checked. These repeats do not add independent
sample statistics.

`decay_handoff/audit.json` records a real two-event graph-copy test. Every
particle, vertex, time, parent/daughter link, native weight and event identity
was preserved. The original GEN input has no persisted physical time; the
completed scout graph has it. The ordinary downstream configuration neither
decays particles again nor shifts time again.

`decay_handoff/full_sim_config_audit.json` records independently resolved
full G4 configurations. G4, LHC transport and all geometry, field and
conditions settings are identical between the ordinary chain and the split
chain. Only the completed input replaces the first decay step. No detector
transport was launched by this audit.

The initial full-chain canary is in `../decay_canary/`, submitted as cluster
12902266. The scout output omits generator-filter Lumi products. The initial
canary did not set `missing_filter_lumi=True`, so its Nano stage may fail on
the optional filter table. The initial review missed that dependency; its
graph/runtime checks remain valid.

The corrected independent deployment is `../decay_canary_v2/`, submitted as
cluster 12902304. It uses the existing frozen worker's
`missing_filter_lumi=True` path. An independent
resolved-config check in `decay_handoff/missing_filter_nano_audit.json` confirms
that only the optional `genFilterTable` is removed from the schedule. All
1,487 declared producer, filter, geometry and field module configurations are
unchanged, including SHIFT reconstruction. The full detector result remains
pending. Neither live deployment was edited by this review.

The inherited parent descriptor hash refers to V8; the direct scout source
descriptor hash refers to V10. Both hashes are correct.
`../decay_canary/upstream_descriptor_clarification.json` records the
V8-to-V10-to-scout-to-canary chain without changing live files.

Successful software, graph and configuration checks do not establish the
final rate, high-mass tail or a measured saving in detector CPU. Those results
remain unfinished.

## Pending outlier states and the next bounded check

The fresh diagnostic Nano and SIM/AOD payloads had not yet been published at
the bounded check near 10:49 UTC. `outlier_state_extractor_receipt.json`
records the prepared read-only extractor and its pending status. No fresh
outlier reproduction, GEN-completeness result or fit-cause conclusion is
claimed yet.

The frozen V10 Step-3 template explicitly calls
`customiseTraversingShiftMuonReco`. It produces and keeps
`shiftCosmicMuonSeed`, `shiftCosmicMuons` and `shiftTraversingMuons` in AOD.
The earlier suggestion that the raw cosmic collections existed only in
Step 4 was wrong. The retained Step-3 AOD should therefore supply the raw
cosmic-track reference, inner and outer detector states and their TrackExtra
and seed references. The bounded extractor reads those exact labels.

The additional timing-directed refit happens inside `ShiftMuonTableProducer`
in Step 4. The existing Nano columns include `trackPt`, `innerPt`, `outerPt`,
`preRefitPt`, `preRefitPz`, `directionalRefitUpstreamP` and the per-iteration
diagnostics. If those are insufficient, a later bounded AOD-to-Step-4 replay
can add a separate diagnostic EDM output and a targeted analyzer for the
refit states. It must retain the exact archived reconstruction, seeds and
event order. No such replay was launched here.

Relevant configuration and source locations are the archived
`validation/ntuple_production_20261007_v10/templates/step3.py` and `step4.py`,
and CMSSW `PhysicsTools/ShiftMuonSegments/python/shiftMuonSegments_customise.py`,
`python/shiftMuonSegments_cfi.py`, and `plugins/ShiftMuonTableProducer.cc`.
Truth CSC hits come from `g4SimHits:MuonCSCHits`; muon truth tracks come from
`g4SimHits`; full pre-detector particles come from `genParticles`.

Any fit diagnosis must compare truth and fitted momentum at the same detector
position. A ratio between reconstructed target-line momentum and production
truth, or a small track chi2, does not by itself identify the cause.
