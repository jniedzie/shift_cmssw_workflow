"""Reopen published J/psi aggregates with the merge's mass-free allowlist."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

directory = Path(__file__).resolve().parent
sys.path.insert(0, str(directory.parents[1] / 'shift_cmssw_workflow/scripts'))
from merge_sampling_nano import inspect

merged = json.loads((directory / 'merges.json').read_text())
verified = []
for group in merged['groups']:
    output = Path(group['output'])
    metadata = json.loads(output.with_suffix('.json').read_text())
    assert metadata == group
    assert hashlib.sha256(output.read_bytes()).hexdigest() == group['sha256']
    rows, schema = inspect(output)
    counts = Counter()
    for row in rows.values():
        counts.update(events=1, events_muon=row['muons'] > 0,
                      events_vertex=row['vertices'] > 0, events_both_both=row['both_both'] > 0)
    assert dict(counts) == group['counts']
    assert len(rows) == group['events'] == 1000 and schema == group['schema_sha256']
    verified.append(dict(output=str(output), counts=dict(counts), sha256=group['sha256']))
    print('Verified published file:', output, flush=True)
(directory / 'published_audit.json').write_text(json.dumps(dict(
    status='validated', groups=verified, reconstructed_mass_read=False), indent=2) + '\n')
(directory / 'ready_inputs.txt').write_text(''.join(row['output'] + '\n' for row in verified))
