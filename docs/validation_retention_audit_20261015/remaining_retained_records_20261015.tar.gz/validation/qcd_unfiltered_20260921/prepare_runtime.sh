#!/usr/bin/env bash
set -euo pipefail
workspace=/afs/cern.ch/work/j/jniedzie/private/shift_cmssw
staging=$(mktemp -d /tmp/shift_runtime_20260922_XXXXXX)
printf 'Runtime staging directory: %s\n' "$staging"
tar --format=pax --exclude=.git --exclude=__pycache__ --exclude=src/plots \
  -C "$workspace/CMSSW_17_0_0_pre4" -czf "$staging/cmssw_runtime.tar.gz" \
  src lib python cfipython config .SCRAM bin external
mkdir "$staging/CMSSW_17_0_0_pre4"
tar -xzf "$staging/cmssw_runtime.tar.gz" -C "$staging/CMSSW_17_0_0_pre4"
unset LD_LIBRARY_PATH PYTHONPATH CMSSW_BASE CMSSW_SEARCH_PATH ROOTSYS
export PATH=/usr/bin:/bin
source /cvmfs/cms.cern.ch/cmsset_default.sh
cd "$staging/CMSSW_17_0_0_pre4/src"
scram b ProjectRename
eval "$(scram runtime -sh)"
python3 - <<'PY'
import os
import PhysicsTools.ShiftMuonSegments.shiftMuonSegments_customise as reco
import IOMC.ShiftEventTiming.shiftEventTiming_customise as timing
for module in (reco,timing):
    assert not module.__file__.startswith('/afs/'), module.__file__
    print(module.__file__)
for key in ('CMSSW_BASE','CMSSW_SEARCH_PATH','LD_LIBRARY_PATH','PYTHONPATH'):
    bad=[value for value in os.environ.get(key,'').split(':') if value.startswith('/afs/')]
    if bad: raise ValueError((key,bad))
print('Local CMSSW runtime imports and search paths verified')
PY
printf 'Runtime archive: %s\n' "$staging/cmssw_runtime.tar.gz"
