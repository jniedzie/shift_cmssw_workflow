<!-- Code style: human-code. -->
# Real and mixed QCD pairs, 15 October 2026

The complete fixed reconstruction sample contains 60,158 original events,
9,955 muons, 451 stored opposite-sign pairs and 113 Both-Both pairs. All native
pair identities and fitted values are reproduced before mixing. The complete
pool includes the 78 recovered events; unfinished nightly returns are excluded.
The separate 496-event tail-targeted production is also outside this fixed
closure sample. Its earlier 21 real high-pT Both-Both pairs are not part of the
zero-tail counts below; no combined old/new sampling weights were changed here.

The fresh run uses 100 donor trials per original event and produces 50,786
Both-Both combinations. Generator bin, original-event fold and CSC occupancy
remain separate. Empty events remain in the donor distribution. The two older
20-trial graphs are independent-seed controls on their original 60,080 events,
under `../mixing_shape_20261015_v3/`.

Each real and mixed distribution is normalized to unit area. The 1,000 shared
original-event Poisson resamples also recompute the donor normalization. Reused
muons do not become independent measurements. The main numerical results are
`fresh_100_shape_closure.json`; plots and their SHA-256 digests are listed in
`study_receipt.json`. An explicit plot-renderer snapshot records the correction
of harmless negative automatic axis padding; the calculations did not change.

Both-Both mass shapes agree within the measured precision: the centered
bootstrap CDF tail fractions are 0.722 over all folds and 0.916 in the held-out
test fold. Pair-pT values are 0.134 and 0.179. The real pairs provide only
14.53 effective original events overall and 5.33 in the test fold.

The harder QCD20+ category needs closer attention. Its 41 real Both-Both pairs
show more balanced muon momenta and lower pair pT than the mixed model. Its
pair-pT diagnostic is 0.021. The separate hard-scale comparison in
`../mixing_hard_scale_shape_20261015_v1/` shows that matching generator pThat
in 20--30 and 30--50 GeV does not remove this difference. These are diagnostic
comparisons across several observables, not a corrected global significance.
The direct charge-aligned log(pT+) versus log(pT-) correlation check is
inconclusive. In QCD20+, real and mixed coefficients are 0.174 and 0.032; the
joint-bootstrap 95% interval for their difference includes zero. This does not
demonstrate that the real muons are correlated or independent. Details are in
`leg_pt_correlation.json`.

`tail_support_summary.json` records 24 mixed mass>20 GeV combinations from
26 original events, and 215 mixed pair-pT>20 GeV combinations from 141 originals.
There are no real pairs in those regions. Real Both-Both masses stop at
9.243 GeV. Agreement in the populated region therefore does not directly
validate the new tails. The three mixed mass>40 GeV combinations use five
original events, with one original touching 66% of their weight.

The uncalibrated event-replacement model predicts 4.749 times the real
Both-Both rate. This shape comparison does not fix the rate. A separate
same-sign calibration study uses physical pair weights and keeps source folds
separate; it must retain its own all-pairs versus best-pair caveat.

The main implementation is
`tea_shift_cmssw/utils/shift_mixing_shape_closure.py`. The focused mixing tests
cover source reuse, donor normalization, repeated-row invariance and matching
pool identities. No canonical sample weights, aliases, detector settings or
training inputs were changed.
