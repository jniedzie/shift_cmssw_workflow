# Code style: AI-code. AI-generated direct muon-correlation diagnostic.
"""Compare the two muon pT values after the same real/mixed pair selection."""
import gzip
import json
from pathlib import Path
import sys

import numpy as np

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "tea_shift_cmssw/utils"))
from shift_mixing import digest, iter_pool, pools_for, validate_inventory, write_json

input_dir = PROJECT / "validation/mixing_poc_20261009"
output = Path(__file__).resolve().parent
events = list(iter_pool(input_dir / "qcd_events.jsonl.gz"))
provenance = validate_inventory(input_dir / "qcd_events.jsonl.gz", input_dir / "input_inventory.json", events)
muons = [{muon["index"]: muon for muon in event["muons"]} for event in events]
groups = np.zeros(len(events), dtype=int)
pools = pools_for(events)
for group, indices in enumerate(pools.values()):
    groups[indices] = group
detector_weight = np.asarray([event["detector_weight"] for event in events])
total = np.bincount(groups, weights=detector_weight, minlength=len(pools))


def load_rows(name, kind):
    result = []
    with gzip.open(input_dir / "full_v4" / name, "rt") as stream:
        for line in stream:
            row = json.loads(line)
            if row["kind"] != kind or not row["both_endcaps"]:
                continue
            first, second = row["anchor_event"], row["donor_event"]
            assert row["source_events"] == [events[index]["event_key"] for index in (first, second)]
            a, b = [muons[index][track] for index, track in zip((first, second), row["source_muons"])]
            assert a["charge"] != b["charge"] and a["pt"] > 0. and b["pt"] > 0.
            positive, negative = (a, b) if a["charge"] > 0 else (b, a)
            result.append(dict(first=first, second=second, weight=row["weight"],
                log_positive_pt=float(np.log(positive["pt"])), log_negative_pt=float(np.log(negative["pt"])),
                stratum=row["stratum"], partition=row["partition"]))
    return result


def arrays(rows):
    return [np.asarray([row[field] for row in rows], dtype=dtype) for field, dtype in
            (("first", int), ("second", int), ("weight", float),
             ("log_positive_pt", float), ("log_negative_pt", float))]


def correlation(data, weights):
    total_weight = weights.sum()
    if total_weight <= 0:
        return None
    x, y = data[3], data[4]
    mean_x, mean_y = weights @ x / total_weight, weights @ y / total_weight
    xx = weights @ ((x - mean_x) ** 2)
    yy = weights @ ((y - mean_y) ** 2)
    if xx <= 0 or yy <= 0:
        return None
    return float(weights @ ((x - mean_x) * (y - mean_y)) / np.sqrt(xx * yy))


same = load_rows("same_event.jsonl.gz", "same_os")
mixed = load_rows("event_replacement.jsonl.gz", "event_os")
results = {}
for stratum in (None, "qcd_20toinf"):
    for partition in (None, "test"):
        keep = lambda row: (stratum is None or row["stratum"] == stratum) and (partition is None or row["partition"] == partition)
        a, b = arrays([row for row in same if keep(row)]), arrays([row for row in mixed if keep(row)])
        nominal_real, nominal_mixed = correlation(a, a[2]), correlation(b, b[2])
        original_donor_sum = total[groups[b[0]]] - detector_weight[b[0]]
        samples = []
        rng = np.random.default_rng(2026101503)
        for _ in range(1000):
            counts = rng.poisson(1., len(events))
            donor_total = np.bincount(groups, weights=counts * detector_weight, minlength=len(pools))
            donor_sum = donor_total[groups[b[0]]] - counts[b[0]] * detector_weight[b[0]]
            correction = np.divide(original_donor_sum, donor_sum,
                                   out=np.zeros(len(b[0])), where=donor_sum > 0)
            real = correlation(a, a[2] * counts[a[0]])
            mock = correlation(b, b[2] * counts[b[0]] * counts[b[1]] * correction)
            if real is not None and mock is not None:
                samples.append((real, mock, mock - real))
        sample = np.asarray(samples)
        label = (stratum or "all_strata") + "/" + (partition or "all_folds")
        results[label] = dict(real_rows=len(a[0]), mixed_rows=len(b[0]),
            nominal_real_correlation=nominal_real, nominal_mixed_correlation=nominal_mixed,
            nominal_mixed_minus_real=nominal_mixed - nominal_real,
            quantiles_025_16_50_84_975=np.quantile(sample, [.025, .16, .5, .84, .975], axis=0).tolist(),
            columns=["real_log_pt_correlation", "mixed_log_pt_correlation", "mixed_minus_real"],
            valid_repetitions=len(samples), repetitions=1000,
            difference_std=float(np.std(sample[:, 2], ddof=1)))
report = dict(schema="shift-mixed-real-muon-logpt-correlation-diagnostic-v1",
    input_provenance=provenance, results=results, source_sha256=digest(Path(__file__)),
    uncertainty="Joint original-event Poisson bootstrap with donor normalization, fixed20-partner graph",
    limitations=["Correlation is measured after the nominal pair cuts, which themselves affect the two legs.",
                 "A different-parent muon pair is not automatically independent.",
                 "The original60080-event graph is a source-control comparison; final mass/pT shapes use the complete60158pool.",
                 "A single correlation coefficient is a diagnostic, not a full independence test."])
write_json(output / "leg_pt_correlation.json", report)
print(json.dumps(report, indent=2))
