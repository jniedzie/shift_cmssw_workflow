# Original-GEN selection study

`qcd_original_gen_features.jsonl.gz` contains the 60,080 completed V10 QCD
events, joined exactly to their original saved GEN events in 709 source files.
It reads no reconstructed muon information as a predictor. Existing detector
weights, source identities, native GEN weights and sampling probabilities are
carried for the separate comparison.

All particle momenta use GeV and production positions use cm in the SHIFT
laboratory frame. The source files precede the additional natural muon-producing
decays used by V10. Stable pions, kaons and strange baryons are therefore the
main candidate parents. Their allowed species come from the same transitive
positive-branching-ratio Pythia table search as `ShiftMuonDecayProducer`.

The CSC line and lifetime calculations are clues for ranking events. They
omit bending, material interactions and reconstruction. They are not detector
acceptance or rate calculations. The comparison found that these parent clues
did not give a useful improvement; see the separate selection result.

`timing_persisted_in_input` in this first table means source-time metadata was
present. It is not a robust test of whether the HepMC graph is already shifted,
because metadata can be dropped separately. Never use that field to configure
replay. The decay scouts independently checked the actual shiftEventTime HepMC
product using the existing worker's `signatures()` function.

All 709 files passed event-identity and native-weight checks. One original file
per bin was copied and independently byte-verified against its frozen SHA256.
The remaining file hashes are inherited from frozen V10 descriptors, as stated
in the extraction receipts. Three focused feature and full-table join tests
passed.

# Natural-decay scout

`decay_scout/two_event/` first checks moving the existing physical decay stage
ahead of detector CPU. Original momenta, positions, weights and identities are
unchanged; natural daughters conserve four-momentum. An independent downstream
copy check confirms that normal SIM preparation consumes the completed graph
without repeating the decay or time shift.

`decay_scout/thousand_event/` contains one fixed natural-decay pass for 1,000
original events across six named source prefixes. All completed graphs and
checksums are retained. It uses the same physical branching ratios and decay
cylinder as V10. No detector simulation runs in this scout. There is no new
decay weight factor and no reroll after seeing the daughter muons.

The 1,000 events contain 4,572 final GEN muons. There are 312 events with two
muon rays crossing CSCs in both endcaps, and 395 with two forward muons above
10 GeV. These are candidate counts, not reconstructed Both-Both counts. The
fixed source prefixes provide method evidence and cannot establish a full-bin
absolute rate. Any later detector selection needs its own recorded positive
sampling probabilities and must consume these exact saved graphs.

The compact scout ROOT files omit the optional `GenFilterInfo` lumi counter.
For these saved graphs, detector source descriptors must set
`missing_filter_lumi: true`. The existing Nano builder then removes its optional
counter table. FWLite checked that the original source had the counter and the
scout did not; separately resolved Nano configs checked the table is removed
only when the flag is true. Evidence is in
`decay_scout/optional_filter_metadata/receipt.json`. Native event weights and
the full original GEN denominators remain preserved separately.

The full-chain canary subsequently failed in Nano. The archived V10 worker
ignores the explicit descriptor flag and passes `stratum.startswith('dy_')`
instead. It therefore still schedules `genFilterTable` for QCD and requests the
missing lumi counter. Both events passed SIM, DIGI/HLT and reconstruction, but
the full chain did not pass. The exact log, resolved config, archived worker
and hashes are in `decay_scout/failure_v2/diagnosis.json` and adjacent files.
The preferred repair is a new scout output retaining the real original lumi
counter, using identical seeds and source events and checking complete graph
and weight equality. No counter should be fabricated, and no new canary was
submitted by this subtask.

The unused `prepare_candidate_gen_pool.py` helper was written for an independent
35k-event first-stage draw. It was not run after the parent-rule comparison
failed. No new Condor jobs were submitted by the extraction subtask.
