#!/usr/bin/env bash
set -eo pipefail
workspace=/afs/cern.ch/work/j/jniedzie/private/shift_cmssw
workflow=$workspace/shift_cmssw_workflow
source /cvmfs/cms.cern.ch/cmsset_default.sh
set -a
JPSI_BIN=${1:-1to2}
N_EVENTS=2
CAMPAIGN_NAME=Jpsi_Unfiltered_pThat_${JPSI_BIN}_ATLASproxy_smoke_20260921_v1
GENERATOR_SEED=81000000
SIMULATION_SEED=82000000
CMSSW_SRC=$workspace/CMSSW_17_0_0_pre4/src
SAMPLE_BASE=/eos/home-j/jniedzie/shift_cmssw
source "$workflow/config/campaigns/jpsi_unfiltered_2023.env"
source "$workflow/config/workflow.env"
set +a
bash "$workflow/scripts/run_condor_job.sh" 0 "$workflow" 1,2,3,4 0 \
  "$PROCESS" "$SAMPLE_NAME" "$CAMPAIGN_NAME" "$SAMPLE_BASE" "$SAMPLE_DIR" "$N_EVENTS"
