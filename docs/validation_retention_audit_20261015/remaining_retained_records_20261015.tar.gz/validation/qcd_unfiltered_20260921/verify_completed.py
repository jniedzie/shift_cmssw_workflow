"""Independent smoke readback: metadata, retained provenance, unit weights; no mass."""
import hashlib
import json
from pathlib import Path
import sys
import ROOT

workspace = Path('/afs/cern.ch/work/j/jniedzie/private/shift_cmssw')
base = Path('/eos/home-j/jniedzie/shift_cmssw')
results = []
cases = [('qcd', f'QCD_UnfilteredDecays_pThat_{bounds}_ATLASproxy_smoke_20260921_v1', bounds, count)
         for bounds, count in [('1to2', 4), ('2to5', 2), ('5to10', 2)]]
cases += [('qcd', 'QCD_UnfilteredDecays_pThat_1to2_ATLASproxy_smoke_final_20260921_v1', '1to2', 2),
          ('jpsi', 'Jpsi_Unfiltered_pThat_1to2_ATLASproxy_smoke_20260921_v1', '1to2', 2)]
for sample, name, bounds, count in cases:
    campaign = base / sample / name
    state = json.loads((campaign / 'chain_metadata/part0000/state.json').read_text())
    assert set(state['stages']) == {'1', '2', '3', '4'}
    metadata = campaign / 'generation_metadata/part0000.json'
    assert hashlib.sha256(metadata.read_bytes()).hexdigest() == state['generation_metadata_sha256']
    gen = json.loads(metadata.read_text())
    assert gen['events'] == gen['attempted_events'] == gen['accepted_events'] == count
    assert gen['generator_filter'] == 'none' and gen['generated_filter_efficiency'] == 1.
    for stage, record in state['stages'].items():
        assert record['output']['event_ids'] == gen['event_ids']
        for path, digest in record['provenance'].items():
            assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest
        if int(stage) < 4:
            assert not Path(record['output']['path']).exists()
            receipt = json.loads((campaign / f'chain_metadata/part0000/retired_step{stage}.json').read_text())
            assert receipt['status'] == 'deleted'
            assert receipt['previous_sha256'] == record['output']['sha256']
    output = state['stages']['4']['output']
    assert hashlib.sha256(Path(output['path']).read_bytes()).hexdigest() == output['sha256']
    f = ROOT.TFile.Open(output['path'])
    assert f and not f.IsZombie() and not f.TestBit(ROOT.TFile.kRecovered)
    t = f.Get('Events'); t.SetBranchStatus('*', 0)
    for branch in ('run', 'luminosityBlock', 'event', 'genWeight', 'nShiftMuon', 'nShiftDimuonVertex'):
        assert t.GetBranch(branch); t.SetBranchStatus(branch, 1)
    ids = []; muon_events = 0; vertex_events = 0
    for e in t:
        ids.append([int(e.run), int(e.luminosityBlock), int(e.event)])
        assert e.genWeight == 1.
        muon_events += int(e.nShiftMuon) > 0
        vertex_events += int(e.nShiftDimuonVertex) > 0
    assert ids == gen['event_ids'] and len(ids) == count
    f.Close()
    results.append(dict(sample=sample, campaign=name, bin=bounds, events=count, events_muon=muon_events, events_vertex=vertex_events,
                        status='validated', all_ids_and_provenance_verified=True,
                        reconstructed_mass_read=False, physics_valid=False))
    print(bounds, count, 'events: ROOT readback, unit weights, provenance and retirement verified')
(workspace / 'validation/qcd_unfiltered_20260921/final_smoke_audit.json').write_text(json.dumps(results, indent=2)+'\n')
