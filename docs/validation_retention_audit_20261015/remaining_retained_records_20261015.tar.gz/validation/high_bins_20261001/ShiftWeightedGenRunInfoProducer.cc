// Persist fixed-budget normalization in EDM. Native generator snapshot may
// predate final rejected trials; this explicitly named product is authoritative.
#include "FWCore/Framework/interface/one/EDProducer.h"
#include "FWCore/Framework/interface/Run.h"
#include "FWCore/Framework/interface/Event.h"
#include "FWCore/Framework/interface/MakerMacros.h"
#include "FWCore/ParameterSet/interface/ParameterSet.h"
#include "FWCore/Utilities/interface/Exception.h"
#include "SimDataFormats/GeneratorProducts/interface/GenRunInfoProduct.h"
#include "nlohmann/json.hpp"
#include <fstream>
#include <cmath>
#include <memory>
class ShiftWeightedGenRunInfoProducer final : public edm::one::EDProducer<edm::EndRunProducer> {
public:
 explicit ShiftWeightedGenRunInfoProducer(edm::ParameterSet const& p):path(p.getParameter<std::string>("statisticsFile")) {
  produces<GenRunInfoProduct,edm::Transition::EndRun>();produces<std::string,edm::Transition::EndRun>("fixedTrialLedger");
 }
 void produce(edm::Event&,edm::EventSetup const&) override {}
 void endRunProduce(edm::Run& run,edm::EventSetup const&) override {
  std::ifstream in(path);nlohmann::json j;in>>j;
  long n=j.at("tried");double w=j.at("sumw"),w2=j.at("sumw2"),nd=j.at("sigma_nd_mb");
  if(!j.at("complete").get<bool>() || j.at("algorithm")!="independent-geometric-full-support-tail-channel-retry-rb-v4" || n!=j.at("requested_trials").get<long>() || n!=j.at("framework_slots").get<long>() || n>j.at("proposal_calls").get<long>() || j.at("proposal_calls")!=j.at("accounted_proposal_calls") || run.run()!=j.at("run").get<unsigned>() || n<2 || !std::isfinite(w) || !std::isfinite(w2) || !std::isfinite(nd) || w<0 || w2<0 || nd<=0)throw cms::Exception("LogicError")<<"Incomplete fixed-trial normalization ledger";
  const double xs=nd*w/n,err=nd*std::sqrt(std::max(0.,w2-w*w/n)/(double(n)*(n-1)));
  auto info=std::make_unique<GenRunInfoProduct>();info->setInternalXSec(GenRunInfoProduct::XSec(xs*1.e9,err*1.e9));info->setFilterEfficiency(1.);
  run.put(std::move(info));run.put(std::make_unique<std::string>(j.dump()),"fixedTrialLedger");
 }
private:std::string path;
};
DEFINE_FWK_MODULE(ShiftWeightedGenRunInfoProducer);
