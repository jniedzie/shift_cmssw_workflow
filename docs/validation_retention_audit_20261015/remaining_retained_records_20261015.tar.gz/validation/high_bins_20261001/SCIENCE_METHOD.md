# Weighted SoftQCD/MPI tail generation

The isolated `independent-geometric-full-support-tail-channel-retry-rb-v4`
proposal samples the unchanged Pythia 8.317 nondiffractive CP5 source more often
in the rare first-MPI tail. It retains the fixed-target proton beams, subsequent
MPI, showers, hadronization, event ownership, and decay settings of the ordinary
production. Detector and trigger settings are outside this GEN method.

At the original sampled impact parameter `b`, write the ordinary conditional
first-scatter distribution as `p_b(dx) = mu_b(dx) / A_b`. Here `mu_b` is one
original acceptance proposal (one complete downward cycle at low impact
parameter), and `A_b` is its probability of producing valid first-scatter
kinematics. An independent original rejection loop supplies a geometric count
`N_b`, including its successful proposal, with `E[N_b | b] = 1/A_b`.

The tail proposal conditions the first overestimate emission or rational
high-impact-parameter proposal on raw first-scatter `pT >= L`; its original
occurrence probability `C_b` is known analytically. At high impact parameter it
integrates the original Bernoulli acceptance into the factor `min(1, WT)`;
nonpositive `WT` or invalid final kinematics contributes zero. At low impact
parameter the original downward thinning remains intact. Failed accepted-WT
channel choices whose final kinematics fails each contribute their channel
likelihood ratio before thinning continues.

For direct J/psi, a channel proposal combines 10% of the original channel
distribution with 90% of the available direct-state channels. The ratio
`q(channel)/q'(channel)` retains nonzero support. The tail first-scatter factor
is `N_b * C_b * thinning_factor * channel_path_ratio`. Its weighted measure,
after averaging over the independent geometric count, is exactly
`p_b(dx) * I(raw pT >= L)`. This is an unbiased weighted-kernel identity; the
random geometric factor is not a pointwise deterministic density ratio.

Pythia can resample the first scatter after an intrinsic parton or hadron
failure without incrementing the native process-trial counter. Restricting
every such scatter to the tail would omit histories that first fail below `L`
and later succeed in the tail. Version 4 therefore uses a disjoint proposal:

- With probability `epsilon = 0.1`, draw the full original conditional first
  scatter. Its factor is `1/epsilon` below `L`, and zero at or above `L`.
- With probability `1-epsilon`, draw the tail proposal and divide its factor
  by `1-epsilon`.

These two weighted measures sum to the complete original `p_b`. Each genuine
`pTfirst()` call multiplies the per-process path weight. Inner beam-remnant
retries that reuse a first scatter do not multiply it again. Iterated
conditional expectation then reproduces the original full intrinsic retry
history. Positive-weight histories undergo the original evolution and late
class/bin veto; only zero-weight proposals may abort early. This ordering is
necessary for the identity. Deliberate vetoes end the framework slot using
`Check:abortIfVeto = on`; this changes batching while retaining native
process-trial accounting. Unexpected terminal failures stop the chunk and
retain its evidence; seeds must never be replaced to bypass a physics failure.

Each chunk has a fixed budget `T` of framework slots, with native `nTried = T`.
The number of genuine first-scatter proposals can exceed `T` and must equal
the explicitly accounted proposal calls. The saved positive event weight is
the complete retry-path product. Rejected slots have weight zero. Normalization
and its fixed-budget sampling error are

```
sigma_bin = sigma_ND * sum(W) / T
error = sigma_ND * sqrt((sum(W^2) - sum(W)^2/T) / (T*(T-1)))
```

The named EDM `shiftWeightedNormalization` run product and its
`fixedTrialLedger` are authoritative. Native `generator` run snapshots may
precede the final rejected trials; native GenLumiInfo counts saved events and
is not the proposal denominator. External GEN filter efficiency is conditional
on retained events and must not be applied again. For combined chunks, add
their trial budgets and weight sums: an event's cross-section weight in pb is
`sigma_ND_pb * W / sum(T)`. Do not divide by the accepted count or effective
event count. `ESS = sum(W)^2/sum(W^2)` measures weighted shape information only.

The independent `ordinary_reference.json` binds preserved ordinary receipts,
resolved configurations, native trial logs and ROOT payloads. Its normalization
uses all 70,000 QCD 5-10 and 1,280 J/psi 2-5 events in the export snapshot; its
ROOT-audited shapes contain 10,000 and 1,280 events respectively. Ordinary chunks
stopped at fixed accepted counts, so their finite-sample ratio convention is a
reference limitation, not a proof of exact unbiasedness. Weighted normalized
CDFs are consistent shape estimators; an ESS-adjusted KS threshold is a
diagnostic, not an exact weighted-distribution significance test.

Production publication requires the semantic ROOT audit: immutable source
settings, fixed beams, complementary direct-state ownership and half-open bins,
positive native/HepMC weights, exact sparse parent identities, recomputed
weight sums, accepted-count equality, and matching embedded ledger/run
normalization. Bounded closure and high-bin effective-event sizing remain
separate gates. Forced `443 -> mu+ mu-` branching conventions, inclusive
twelve-stratum closure, and CMS physics readiness remain explicitly unresolved;
these GEN artifacts retain `physics_valid = false` and
`normalization_ready = false`.
