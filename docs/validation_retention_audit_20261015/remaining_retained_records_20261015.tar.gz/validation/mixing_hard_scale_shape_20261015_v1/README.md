<!-- Code style: human-code. -->
# Does matching the hard scale improve mixing?

This comparison uses the complete QCD reconstruction sample and independently
read Nano `Generator_binvar` values, joined by exact original-event identity.
The values have the precision stored in Nano. Existing generator strata never
change because of a rounded value.

The predeclared hard-scale intervals are 20--30, 30--50 and 50+ GeV. No accepted
source has a stored value above 39.4 GeV, so the last interval is empty. All
campaign, generator-bin, original-event fold and occupancy restrictions remain.

Of 10,111 QCD20+ originals, four have no distinct donor in the finer pools.
Both models use the same remaining 10,107 originals. Two inclusive real pairs
are excluded by that source-only requirement; no Both-Both pair is excluded.
There are 10,057 originals in 20--30 and 50 in 30--50. All 41 real Both-Both
pairs are in 20--30.

Each model uses 100 donor trials and 1,000 shared original-event resamples,
including its own correct donor normalization. The ordinary versus matched
Both-Both pair-pT CDF distances are 0.190 versus 0.183. Centered-bootstrap tail
fractions are 0.022 versus 0.026. Mass values are 0.418 versus 0.437. Matching
the common generator hard scale therefore does not explain the pT difference.
The held-out hard-bin sample has only five real Both-Both pairs.

Results, source exclusions, intervals and final PDF SHA-256 digests are in
`hard_scale_closure.json`. Exact input hashes are in `input_provenance.json`.
The reproducible driver is `../mixing_hard_scale_shape_20261015_v1.py`; maintained
calculations are in `tea_shift_cmssw/utils/shift_mixing_shape_closure.py`.
