# Code style: AI-code. AI-generated publication and numerical audit.
"""Refresh plot axes and record tail support without changing calculations."""
from collections import Counter
import gzip
import json
from pathlib import Path
import shutil
import sys

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "tea_shift_cmssw/utils"))
from shift_mixing import DEFAULT_CONFIG, digest, iter_pool, same_event_rows, write_json
from shift_mixing_shape_closure import draw_shapes


for directory in (PROJECT / "validation/mixing_shape_20261015_v3", Path(__file__).resolve().parent):
    receipt_path = directory / "study_receipt.json"
    receipt = json.loads(receipt_path.read_text())
    snapshot = directory / "plot_renderer_snapshot"
    snapshot.mkdir(exist_ok=True)
    source = PROJECT / "tea_shift_cmssw/utils/shift_mixing_shape_closure.py"
    shutil.copy2(source, snapshot / source.name)
    for graph, metadata in receipt["graphs"].items():
        record = json.loads(Path(metadata["result_path"]).read_text())
        for label, result in record["results"].items():
            category, partition = label.split("/")
            file_name = graph + "_" + category.replace("-", "_") + "_" + partition + ".pdf"
            item = next(item for item in receipt["publication"] if Path(item["path"]).name == file_name)
            draw_shapes(result, Path(item["path"]), category, partition, graph)
        for stratum, result in record.get("both_both_generator_bin_shapes", {}).items():
            if not result["available"]:
                continue
            item = next(item for item in receipt["publication"]
                        if Path(item["path"]).name == "fresh_Both_Both_" + stratum + ".pdf")
            draw_shapes(result, Path(item["path"]), "Both-Both " + stratum, "all folds", graph)
        if "different_parent_real_diagnostic" in record:
            item = next(item for item in receipt["publication"]
                        if Path(item["path"]).name == "fresh_Both_Both_different_parent_diagnostic.pdf")
            draw_shapes(record["different_parent_real_diagnostic"], Path(item["path"]),
                        "Both-Both different-parent diagnostic", "all folds", graph)
    for item in receipt["publication"]:
        item["previous_publication_sha256"] = item["sha256"]
        item["sha256"] = digest(Path(item["path"]))
    receipt["plot_renderer_sha256"] = digest(source)
    receipt["plot_axis_update"] = "Show the declared nonnegative observable domain; no input, weights, calculation or interval changed."
    write_json(receipt_path, receipt)
    print("Published and checked", len(receipt["publication"]), "PDFs in", directory, flush=True)

directory = Path(__file__).resolve().parent
pool = PROJECT / "validation/qcd_gen_recovery_20261015/mixing_complete_baseline_v1/qcd_events.jsonl.gz"
events = list(iter_pool(pool))
same = same_event_rows(events, DEFAULT_CONFIG)
real = [row for row in same if row["kind"] == "same_os" and row["both_endcaps"]]
mixed = []
with gzip.open(directory / "fresh_event_replacement.jsonl.gz", "rt") as stream:
    for line in stream:
        row = json.loads(line)
        if row["both_endcaps"]:
            mixed.append(row)
summary = dict(input_events=len(events), input_muons=sum(len(event["muons"]) for event in events),
               real_both_both_os_pairs=len(real), mixed_both_both_os_combinations=len(mixed),
               model_tail_support_does_not_validate_physical_tail=True, thresholds={})
for variable in ("mass", "pt"):
    for cut in (10., 20., 40., 70.):
        target = [row for row in real if row["pair"][variable] > cut]
        model = [row for row in mixed if row["pair"][variable] > cut]
        touched = Counter()
        for row in model:
            for original in set(row["source_events"]):
                touched[original] += row["weight"]
        total = sum(row["weight"] for row in model)
        summary["thresholds"][variable + ">" + str(cut)] = dict(
            real_pairs=len(target), mixed_combinations=len(model), mixed_originals=len(touched),
            mixed_shape_fraction=total / sum(row["weight"] for row in mixed),
            largest_original_touched_fraction=max(touched.values()) / total if total else None,
            real_weight_pb=sum(row["weight"] for row in target), model_weight_pb=total)
summary["maximum_real_both_mass_GeV"] = max(row["pair"]["mass"] for row in real)
summary["maximum_mixed_both_mass_GeV"] = max(row["pair"]["mass"] for row in mixed)
summary["same_sign_controls"] = {}
for partition in (None, "test"):
    rows = [row for row in same if row["kind"] == "same_ss" and row["both_endcaps"]
            and (partition is None or row["partition"] == partition)]
    weights = [row["weight"] for row in rows]
    summary["same_sign_controls"][partition or "all"] = dict(
        pairs=len(rows), effective_originals=sum(weights) ** 2 / sum(value ** 2 for value in weights))
write_json(directory / "tail_support_summary.json", summary)
print(json.dumps(summary, indent=2), flush=True)
