<!-- Code style: AI-code. AI-generated frozen GEN cue inventory notes. -->

This folder preserves a possible later reconstruction target. It does not change
the submitted or prepared tail draw and does not assign another sampling
probability.

The complete original QCD GEN scan contains 1,550 events with at least two stored
muon straight lines crossing at least two CSC stations in each endcap. The old
draw selected 17 of these. The ledger here records the remaining 1,533 exact
original identities, raw GEN indices, native double weights and scalar features.
Of these, 116 are already selected by the current frozen tail draw. Another
1,417 lie outside that draw. None overlaps the two separate cost canaries.

The 116 new tail events all belong to QCD pThat20+. Their native sum of weights
is 7.137585355367186e-8 and their native effective count is 18.025576331665626.
The single previously processed tail original also has this line cue. It carries
94.9677105264659% of the native weight of all 117 tail originals with the cue.
These are GEN population moments, not reconstructed Both-Both precision.

The 1,417 events outside the current draw have neither stored GEN muon pT above
20 GeV nor stored opposite-sign dimuon mass above 20 GeV. They could help test
the Both-Both reconstruction and lower tails; their line geometry does not show
that they will populate the requested high pT or mass region. Natural additional
parent decays, field, material, timing, trigger and actual reconstruction still
need to be applied.

Before using any later geometry-based draw, freeze its rule over the full original
GEN population and keep positive support for events with no stored muons that
can gain muons after parent decay. Recompute the combined selection probability
for every old and new original, update the matched weight overlays, keep one
row per original and preserve the full original GEN normalization. These rows
must not simply be appended with the current draw's weights.

`inventory_receipt.json` binds the ledger to the full reconciled scan, old
selection ledger and current frozen draw. The old logical scan archive paths
remain in the provenance; root's verified relocation receipt maps them to the
versioned EOS support archive. Feature extraction was read from task scratch.
`current_draw_Both2_weight_summary.json` records the separate 116-event and
117-event native weight moments and the exact previously processed original.
