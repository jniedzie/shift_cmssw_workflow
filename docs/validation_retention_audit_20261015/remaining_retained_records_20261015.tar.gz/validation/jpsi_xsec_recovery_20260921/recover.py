#!/usr/bin/env python3
"""Recover missing exports from existing 5000-attempt GEN estimates; no ROOT reads.

The dated campaign list is deliberate. Never overwrite an existing estimate.
Run without --publish to validate everything before touching campaign outputs.
"""
import argparse
import ast
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import tempfile

WORKSPACE = Path(__file__).resolve().parents[2]
BASE = Path('/eos/home-j/jniedzie/shift_cmssw/jpsi')
UPDATER = WORKSPACE / 'shift_cmssw_workflow/scripts/update_cross_section.sh'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def generator_signature(path):
    nodes = {ast.unparse(n.targets[0]): n.value for n in ast.parse(path.read_text()).body
             if isinstance(n, ast.Assign) and len(n.targets) == 1}
    # Match the complete generator, including CMS common/CP5 and beam settings,
    # and the generation path (no added generator filter).
    payload = [ast.dump(nodes[k]) for k in ('process.generator', 'process.generation_step')]
    return hashlib.sha256('\n'.join(payload).encode()).hexdigest()


def campaign(lo, hi, tag):
    return BASE / f'SamplingScan_jpsi_pThat_{lo}to{hi}_{tag}_20260921_v1'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--publish', action='store_true')
    args = parser.parse_args()
    records = []
    for lo, hi in ((1, 2), (2, 5), (5, 10), (10, 20), (20, -1)):
        source = campaign(lo, hi, 'scanretry' if lo == 2 else 'scan') / 'sampling_pilot/gen/part0000'
        report_path, config, log = source / 'report.json', source / 'step1_cfg.py', source / 'step1.log'
        report = json.loads(report_path.read_text())
        contract, gen = report['contract'], report['generation']
        assert report['status'] == 'validated'
        assert (contract['sample'], contract['lower'], contract['upper'], contract['mode'],
                contract['attempted_events']) == ('jpsi', lo, hi, 'gen', 5000)
        assert sha(config) == contract['config_sha256']
        assert gen['accepted_events'] == gen['attempted_events'] > 4900
        assert len(gen['runs']) == 1
        sigma, error = gen['runs'][0]['internal_xsec_pb'], gen['runs'][0]['error_pb']
        assert math.isfinite(sigma) and sigma > 0 and math.isfinite(error) and error >= 0
        signature = generator_signature(config)
        targets, checked = [], []
        for tag, count in (('scan', 10), ('analysis1k_chunk50', 20)):
            target = campaign(lo, hi, tag)
            configs = sorted((target / 'sampling_pilot/full').glob('part*/step1_cfg.py'))
            assert len(configs) == count, (target, len(configs))
            for other in configs:
                assert generator_signature(other) == signature, other
                checked.append(dict(path=str(other), sha256=sha(other)))
            targets.append(target)
        with tempfile.TemporaryDirectory(prefix='shift_xsec_') as scratch:
            output = Path(scratch) / 'cross_sections.txt'
            subprocess.run(['bash', str(UPDATER), str(log), str(output), 'jpsi'], check=True)
            line = output.read_text().splitlines()[1]
            values = re.findall(r'(?:before_filter|after_filter)=([0-9.eE+-]+) \+- ([0-9.eE+-]+) pb', line)
            assert len(values) == 2
            for value, uncertainty in values:
                assert math.isclose(float(value), sigma, rel_tol=5.e-4)
                assert math.isclose(float(uncertainty), error, rel_tol=5.e-4)
        record = dict(bin_pthat_GeV=[lo, hi], internal_xsec_pb=sigma, error_pb=error,
                      estimate_framework_attempts=5000, estimate_generated_events=gen['attempted_events'],
                      source_report=str(report_path), source_report_sha256=sha(report_path),
                      source_log=str(log), source_log_sha256=sha(log), source_config=str(config),
                      source_config_sha256=sha(config), generator_signature_sha256=signature,
                      checked_target_configs=checked, targets=[str(t) for t in targets],
                      physics_valid=False, normalization_ready=False,
                      convention='Raw GenXsecAnalyzer estimate for forced-dimuon direct J/psi. '
                                 'No extra branching fraction, luminosity or reconstruction/trigger '
                                 'efficiency applied. Forced-decay normalization remains provisional. '
                                 'GEN estimate event count is not the reconstructed sample denominator.')
        records.append(record)
    # All five bins/configurations/log-to-run comparisons passed before any write.
    for record in records:
        for target_string in record['targets']:
            target = Path(target_string)
            provenance = target / 'cross_sections.provenance.json'
            content = json.dumps(record, indent=2) + '\n'
            if provenance.exists():
                assert provenance.read_text() == content, provenance
            elif args.publish:
                with provenance.open('x') as stream:
                    stream.write(content)
            if args.publish:
                output = target / 'cross_sections.txt'
                subprocess.run(['bash', str(UPDATER), record['source_log'], str(output), target.name], check=True)
                line = output.read_text().splitlines()[1]
                values = re.findall(r'(?:before_filter|after_filter)=([0-9.eE+-]+) \+- ([0-9.eE+-]+) pb', line)
                assert len(values) == 2
                for value, uncertainty in values:
                    assert math.isclose(float(value), record['internal_xsec_pb'], rel_tol=5.e-4)
                    assert math.isclose(float(uncertainty), record['error_pb'], rel_tol=5.e-4)
        print(record['bin_pthat_GeV'], record['internal_xsec_pb'], '+-', record['error_pb'], 'pb')
    if args.publish:
        summary = Path(__file__).with_name('recovery.json')
        content = json.dumps(dict(status='validated', records=records), indent=2) + '\n'
        if summary.exists():
            assert summary.read_text() == content
        else:
            with summary.open('x') as stream:
                stream.write(content)
    print('Published and read back 10 exports' if args.publish else 'Dry run passed; no campaign files changed')


if __name__ == '__main__':
    main()
